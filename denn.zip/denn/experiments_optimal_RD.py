import torch
import torch.nn as nn
import argparse
import numpy as np

from denn.algos_RD_dis import train_L2_2D, train_L2_2D_soft, train_GAN_2D, train_LuLu_penalty, train_LuLu_augment
from denn.models import MLP, MultiHeadGen
from denn.pretrained import get_pretrained
from denn.config.config import get_config
import denn.pde_RD_dis as pde_opti

def get_problem(pkey, params):
    """ helper to parse problem key and return appropriate problem
    """
    pkey = pkey.lower().strip() #把所有字母变为小写、去掉前后空格
    if pkey == 'heatrddis':
        return pde_opti.RDDisEquation(**params['problem'])
    else:
        raise RuntimeError(f'Did not understand problem key (pkey): {pkey}')

def L2_experiment(pkey, params):
    # model init seed
    torch.manual_seed(0)
    np.random.seed(0)

    # model1
    if params['generator1']['pretrained']:
        model1 = get_pretrained(pkey, params)
    elif pkey.lower().strip() in ["rays"]:
        model1 = MultiHeadGen(**params['generator1'])
    else:
        model1 = MLP(**params['generator1'])

    # model2
    if params['generator2']['pretrained']:
        model2 = get_pretrained(pkey, params)
    elif pkey.lower().strip() in ["rays"]:
        model2 = MultiHeadGen(**params['generator2'])
    else:
        model2 = MLP(**params['generator2'])
    # experiment seed
    np.random.seed(params['training']['seed'])
    torch.manual_seed(params['training']['seed'])
    # run
    problem = get_problem(pkey, params)
    res = train_L2_2D(model1, model2, problem, **params['training'], config=params)
    return res

def L2_experiment_soft(pkey, params):
    # model init seed
    torch.manual_seed(0)
    np.random.seed(0)

    # model1
    if params['generator1']['pretrained']:
        model1 = get_pretrained(pkey, params)
    elif pkey.lower().strip() in ["rays"]:
        model1 = MultiHeadGen(**params['generator1'])
    else:
        model1 = MLP(**params['generator1'])

    # model2
    if params['generator2']['pretrained']:
        model2 = get_pretrained(pkey, params)
    elif pkey.lower().strip() in ["rays"]:
        model2 = MultiHeadGen(**params['generator2'])
    else:
        model2 = MLP(**params['generator2'])
    # experiment seed
    np.random.seed(params['training']['seed'])
    torch.manual_seed(params['training']['seed'])

    # run
    problem = get_problem(pkey, params)
    res = train_L2_2D_soft(model1, model2, problem, **params['training'], config=params)
    return res

def gan_experiment(pkey, params):
    # model init seed
    torch.manual_seed(0)
    np.random.seed(0)

    # models
    if params['generator1']['pretrained']:
        gen1 = get_pretrained(pkey, params)
    elif pkey.lower().strip() in ["rays"]:
        gen1 = MultiHeadGen(**params['generator1'])
    else:
        gen1 = MLP(**params['generator1'])

    disc1 = MLP(**params['discriminator1'])
    #print(disc1)
    if params['generator2']['pretrained']:
        gen2 = get_pretrained(pkey, params)
    elif pkey.lower().strip() in ["rays"]:
        gen2 = MultiHeadGen(**params['generator2'])
    else:
        gen2 = MLP(**params['generator2'])

    disc2 = MLP(**params['discriminator2'])

    # experiment seed
    torch.manual_seed(params['training']['seed'])
    np.random.seed(params['training']['seed'])

    # run pde用2D的训练
    problem = get_problem(pkey, params)
    res = train_GAN_2D(gen1, disc1, gen2, disc2, problem, **params['training'], config=params)

    return res

def L2_LuLu_penalty(pkey, params):
    # model init seed
    torch.manual_seed(0)
    np.random.seed(0)

    # model1
    if params['generator1']['pretrained']:
        model1 = get_pretrained(pkey, params)
    elif pkey.lower().strip() in ["rays"]:
        model1 = MultiHeadGen(**params['generator1'])
    else:
        model1 = MLP(**params['generator1'])

    # model2
    if params['generator2']['pretrained']:
        model2 = get_pretrained(pkey, params)
    elif pkey.lower().strip() in ["rays"]:
        model2 = MultiHeadGen(**params['generator2'])
    else:
        model2 = MLP(**params['generator2'])
    # experiment seed
    np.random.seed(params['training']['seed'])
    torch.manual_seed(params['training']['seed'])

    # run
    problem = get_problem(pkey, params)
    res = train_LuLu_penalty(model1, model2, problem, **params['training'], config=params)

    return res

def L2_LuLu_augent(pkey, params):
    # model init seed
    torch.manual_seed(0)
    np.random.seed(0)

    # model1
    if params['generator1']['pretrained']:
        model1 = get_pretrained(pkey, params)
    elif pkey.lower().strip() in ["rays"]:
        model1 = MultiHeadGen(**params['generator1'])
    else:
        model1 = MLP(**params['generator1'])

    # model2
    if params['generator2']['pretrained']:
        model2 = get_pretrained(pkey, params)
    elif pkey.lower().strip() in ["rays"]:
        model2 = MultiHeadGen(**params['generator2'])
    else:
        model2 = MLP(**params['generator2'])
    # experiment seed
    np.random.seed(params['training']['seed'])
    torch.manual_seed(params['training']['seed'])

    # run
    problem = get_problem(pkey, params)
    res = train_LuLu_augment(model1, model2, problem, **params['training'], config=params)

    return res

if __name__ == '__main__':
    args = argparse.ArgumentParser()
    args.add_argument('--gan', action='store_true', default=True,
        help='whether to use GAN-based training, default False (use L2-based)')
    args.add_argument('--pkey', type=str, default='heatrddis',
        help='problem to run (exp=Exponential, sho=SimpleOscillator, nlo=NonlinearOscillator)')
    args.add_argument('--mkey', action='store_true', default=False,
        help='whether to use traditional L2 training with soft constrain, default False (use L2-based)')
    args.add_argument('--lup', action='store_true', default=True,
                      help='whether to use LuLu penalty')
    args.add_argument('--lua', action='store_true', default=False,
                      help='whether to use LuLu augment lagrange')
    args = args.parse_args()

    params = get_config(args.pkey)

    if args.gan:
        print(f'Running GAN training for {args.pkey} problem...')
        gan_experiment(args.pkey, params)
    elif args.mkey:
        print(f'Running classical training with soft constrain for {args.pkey} problem...')
        L2_experiment_soft(args.pkey, params)
    elif args.lup:
        print(f'Running LuLu penalty for {args.pkey} problem...')
        L2_LuLu_penalty(args.pkey, params)
    elif args.lua:
        print(f'Running LuLu augment lagrange for {args.pkey} problem...')
        L2_LuLu_augent(args.pkey, params)
    else:
        print(f'Running L2-based training for {args.pkey} problem...')
        L2_experiment(args.pkey, params)
    # from denn.utils import diff

    # params = get_config('exp')
    # G = MLP(**params['generator'])
    # D = MLP(**params['discriminator'])

    # def _exp_eqn(x, t):
    #     return diff(x, t) + x

    # def adjust(x, t):
    #     x_adj = 1 + (1 - torch.exp(-t)) * x
    #     return x_adj

    # def get_equation(x, t):
    #     adj_x = adjust(x, t)
    #     return _exp_eqn(adj_x, t)

    # grid_samp = torch.linspace(0, 10, 100, requires_grad=True).reshape(-1, 1) # get grid
    # pred = G(grid_samp) # make prediction
    # residuals = get_equation(pred, grid_samp) # get residuals
    # fake = residuals

    # g_loss = D(fake).sum() # calculate some generator loss based on residuals
    # g_loss.backward(retain_graph=True)

    # d_loss = D(fake.detach()).sum() # calculate some descriminator loss
    # d_loss.backward()

    # grads = diff(residuals, grid_samp)
