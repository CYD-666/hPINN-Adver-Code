import os
import yaml

this_dir = os.path.dirname(os.path.abspath(__file__))
"""get_config函数讲解：
    os.path.join(this_dir, f'{problem_key}.yaml')
    构建了要读取的 YAML 文件的路径。this_dir 是包含当前模块
    文件的目录，而 f'{problem_key}.yaml' 则构建了对应的 YAML 文件名。
    这个函数的作用是从指定的 YAML 配置文件中加载问题的参数，并将这些参数
    作为字典返回。它允许用户通过指定问题的关键字来获取相应的参数配置，使
    得代码更加模块化和可扩展。"""
def get_config(problem_key):
    """ valid pkeys = EXP, SHO, NLO, POS """
    problem_key = problem_key.strip().lower()
    fname = os.path.join(this_dir, f'{problem_key}.yaml')
    with open(fname, 'r') as f:
        params = yaml.full_load(f)
    return params

def write_config(config_dict, save_path):
    with open(save_path, 'w') as f:
        yaml.dump(config_dict, f)

if __name__ == '__main__':
    print(get_config('exp'))
