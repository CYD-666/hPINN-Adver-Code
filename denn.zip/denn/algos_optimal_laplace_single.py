import numpy as np
import torch
import torch.nn as nn
import os
import time
import torch.nn.functional as F
from denn.utils_laplace_single import plot_results_gan, plot_results_L2, plot_multihead, calc_gradient_penalty, \
    handle_overwrite, plot_3D, plot_lulu_penalty, plot_lulu_augment
from denn.config.config import write_config

try:
    from ray import tune
except:
    print("Ray not loaded.")

this_dir = os.path.dirname(os.path.abspath(__file__))

def train_GAN_2D(G1, D1, G2, problem, method='unsupervised', niters=100,
                 g_lr=1e-3, g_betas=(0.0, 0.9), d_lr=1e-3, d_betas=(0.0, 0.9),
                 lr_schedule=True, gamma=0.999, momentum=0.95, noise=False,
                 step_size=15, obs_every=1, d1=1., d2=1., G_iters=1, D1_iters=1, D2_iters=1,
                 wgan=True, gp=0.1, conditional=True, train_mse=True, log=True,
                 plot=True, plot_1d_curves=False, save=False, dirname='train_GAN',
                 config=None, save_for_animation=False, view=[35, -55], K=0, beta=0.5, **kwargs):

    assert method in ['supervised', 'semisupervised', 'unsupervised'], f'Method {method} not understood!'

    pkey = dirname.split('_')[0].lower()

    dirname = os.path.join(this_dir, '../experiments/runs', dirname)

    if plot and save:  # 在pde.problem中plot和save是true
        handle_overwrite(dirname)  # 调用了函数，当plot和save都是true时看是否覆盖原来的文件
        # 如果不覆盖程序会终止
    # validation: fixed grid/solution提供一个固定的验证数据集，用于在训练过程中对模型进行评估和监控。
    x, y = problem.get_grid()  # 返回具体问题problem的网格 x，y，problem里的所有数据是按照行来的，不同于PINN中的列
    grid = torch.cat((x, y), 1)  # 与pinn中数据刚好反着来，给的是每一行的节点（x,t），时间在变
    soln = problem.get_solution(x, y)  # 返回具体问题的解析解和最终时刻的解

    # initialize residuals and grid for active sampling这些初始化步骤是为了准备进行激活采样，它们会在训练的过程中
    # 动态更新，以适应模型的训练需求。所以需要保存残差梯度。
    grid_samp = grid
    residuals = torch.zeros_like(x)  # 每个节点都对应一个值为0的残差（PDE）
    residuals_delta = torch.zeros_like(grid_samp)

    # grid for plotting and animation
    if plot or save_for_animation:
        dims = problem.get_plot_dims()  # 获取网格x和t的节点个数
        plot_x, plot_t = problem.get_plot_grid()  # 获取需要作图的网格
        #plot_x_t = torch.ones_like(plot_x)
        plot_grid = torch.cat((plot_x, plot_t), 1)
        #plot_grid_t = torch.cat((plot_x, plot_x_t), 1)# 把作图网格变成想要的数据格式
        plot_soln = problem.get_plot_solution(plot_x, plot_t)  # 获得作图网格下的精确解

    # labels 给样本添加标签
    real_label = 1  # 真实标签
    fake_label = 0  # 虚假标签
    real_labels1 = torch.full((len(grid)+1,), real_label, dtype=torch.double).reshape(-1, 1)  # len(grid)+195 for no reparam
    #real_labels2 = torch.full((1,), real_label, dtype=torch.double).reshape(-1, 1)  # len(grid)+195 for no reparam
    fake_labels1 = torch.full((len(grid)+1,), fake_label, dtype=torch.double).reshape(-1, 1)  # len(grid)+195 for no reparam
    #fake_labels2 = torch.full((1,), fake_label, dtype=torch.double).reshape(-1, 1)  # len(grid)+195 for no reparam

    # initialize difference parameter for noise
    if noise:
        diff1 = 0
        #diff2 = 0

    # optimization 给生成器和判别器生成了优化器
    optiG1 = torch.optim.Adam(G1.parameters(), lr=g_lr, betas=g_betas)
    optiD1 = torch.optim.Adam(D1.parameters(), lr=d_lr, betas=d_betas)
    optiG2 = torch.optim.Adam(G2.parameters(), lr=g_lr, betas=g_betas)
    #optiD2 = torch.optim.Adam(D2.parameters(), lr=d_lr, betas=d_betas)
    if lr_schedule:
        lr_scheduler_G1 = torch.optim.lr_scheduler.StepLR(optimizer=optiG1, step_size=step_size, gamma=gamma)
        lr_scheduler_D1 = torch.optim.lr_scheduler.StepLR(optimizer=optiD1, step_size=step_size, gamma=gamma)
        lr_scheduler_G2 = torch.optim.lr_scheduler.StepLR(optimizer=optiG2, step_size=step_size, gamma=gamma)
        #lr_scheduler_D2 = torch.optim.lr_scheduler.StepLR(optimizer=optiD2, step_size=step_size, gamma=gamma)
        # step_size是步长，表示多少个epoch调整一次学习率；gamma是衰减率，表示每次调整时学习率的衰减比例。
        # 可以先不进行学习率调度，看看多少步后停止，再进行调度
    # losses 确定gan的损失函数是二元交叉熵损失还是wgan损失
    bce = nn.BCELoss()  # 二元交叉熵损失
    criterion = bce  # 判断真实样本和生成虚假样本的距离

    # history
    losses1 = {'G1': [], 'D1': []}  # , 'LHS': []}
    losses2 = {'G2': [], 'D2': []}  # , 'LHS': []}

    preds = {'pred': [], 'control': []}  # 作图用
    resids = {'resid': []}
    cost_objective = {'cost':[]}

    tolerance_counter1 = 0
    tolerance_limit1 = 500
    #tolerance_counter2 = 0
    #tolerance_limit2 = 500
    time_start = time.time()
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    for epoch in range(niters):
        # Train Generator
        for p in D1.parameters():
            p.requires_grad = False  # turn off computation for D 关闭判别器D1的参数梯度计算
        #for p in D2.parameters():
        #    p.requires_grad = False  #关闭判别器D2的参数梯度计算

        for i in range(G_iters):
            xs, ys = problem.get_grid_sample()
            xs = xs.to(device)
            ys = ys.to(device)
            grid_samp = torch.cat((xs, ys), 1)
            pred1 = G1(grid_samp)
            pred2 = G2(xs)
            #print("Model device:", next(G1.parameters()).device)
            xs_mean, ys_mean = problem.get_grid_sample_top_wall()
            grid_samp_mean = torch.cat((xs_mean, ys_mean), 1)
            residuals1 = problem.get_equation(pred1, pred2, G2, xs, ys)
            pred1_mean = G1(grid_samp_mean)
            pred2_mean = G2(xs_mean)
            cost_objective1 = problem.get_cost(pred1_mean, pred2_mean, G2, xs_mean, ys_mean)
            #cost_objective1 = cost_objective1.unsqueeze(0).unsqueeze(0)
            cost_objective1 = cost_objective1.view(1, 1)
            combined_input = torch.cat([residuals1, cost_objective1], dim=0)  # shape: [N_f + 1]
            if noise:
                diff1 = diff1 if diff1 >= 0 else 0
                #diff2 = diff2 if diff2 >= 0 else 0
                real1 = torch.zeros_like(combined_input) + torch.normal(0, diff1, size=combined_input.shape)
                fake1 = combined_input + torch.normal(0, diff1, size=combined_input.shape)
                #real2 = torch.zeros_like(cost_objective1) + torch.normal(0, diff2, size=cost_objective1.shape)
                #fake2 = cost_objective1 + torch.normal(0, diff2, size=cost_objective1.shape)
            else:
                real1 = torch.zeros_like(combined_input)
                fake1 = combined_input
                #real2 = torch.zeros_like(cost_objective1)
                #fake2 = cost_objective1
            # fake = residuals

            optiG1.zero_grad()  # 在每次更新生成器之前，需要将梯度清零，以确保不会累积之前的梯度信息。
            optiG2.zero_grad()  # 在每次更新生成器之前，需要将梯度清零，以确保不会累积之前的梯度信息。
            g_loss1 = criterion(D1(fake1), real_labels1)    # 鉴别器的输出是对输入生成样本的一个判断概率，1就是真实样本，0就是虚假
            #g_loss2 = criterion(D2(fake2), real_labels2)
            g_loss = g_loss1 #+ g_loss2
            g_loss.backward()
            optiG1.step()
            optiG2.step()

        # Train Discriminator1
        for p in D1.parameters():
            p.requires_grad = True  # turn on computation for D

        for i in range(D1_iters):
            norm_penalty = torch.zeros(1)

            # print(real.shape, fake.shape)
            real_loss1 = criterion(D1(real1), real_labels1)
            fake_loss1 = criterion(D1(fake1.detach()), fake_labels1)
            optiD1.zero_grad() # 在每次更新生成器之前，需要将梯度清零，以确保不会累积之前的梯度信息。
            d_loss1 = (real_loss1 + fake_loss1) / 2 + norm_penalty
            d_loss = d_loss1
            d_loss.backward()
            optiD1.step()

        # 检查 g_loss1 和 d_loss1 的误差绝对值
        if abs(g_loss1.item() - d_loss1.item()) < 1e-6:
            tolerance_counter1 += 1  # 增加计数器
        else:
            tolerance_counter1 = 0  # 误差不满足条件时重置计数器

        '''# Train Discriminator2
        for p in D1.parameters():
            p.requires_grad = False  # turn on computation for D

        for p in D2.parameters():
            p.requires_grad = True  # turn on computation for D

        for i in range(D2_iters):
            norm_penalty = torch.zeros(1)

            # print(real.shape, fake.shape)
            real_loss2 = criterion(D2(real2), real_labels2)
            fake_loss2 = criterion(D2(fake2.detach()), fake_labels2)

            optiD2.zero_grad()  # 在每次更新生成器之前，需要将梯度清零，以确保不会累积之前的梯度信息。
            d_loss2 = (real_loss2 + fake_loss2) / 2 + norm_penalty
            d_loss = d_loss2
            d_loss.backward()
            optiD2.step()

        if abs(g_loss2.item() - d_loss2.item()) < 1e-6:
            tolerance_counter2 += 1  # 增加计数器
        else:
            tolerance_counter2 = 0'''

        if tolerance_counter1 >= tolerance_limit1:
            break  # 终止当前迭代，开始下一次迭代

            # update the difference between losses
        if noise:
            diff1 = g_loss1.item() - d_loss1.item()
            #diff2 = g_loss2.item() - d_loss2.item()

        losses1['D1'].append(d_loss1.item())
        losses1['G1'].append(g_loss1.item())
        #losses2['D2'].append(d_loss2.item())
        #losses2['G2'].append(g_loss2.item())
        # losses['LHS'].append(torch.mean(torch.abs(fake)).item())

        if lr_schedule:
            lr_scheduler_G1.step()
            lr_scheduler_D1.step()
            lr_scheduler_G2.step()
            #lr_scheduler_D2.step()

        # save preds and residuals for animation
        if save_for_animation:
            plot_pred1 = G1(plot_grid)
            plot_pred2 = G2(plot_x)
            plot_pred_adj1 = problem.adjust(plot_pred1, plot_pred2,G2, plot_x, plot_t)['pred']
            #plot_pred_adj2 = problem.adjust(plot_pred1, plot_pred2, plot_x, plot_t)['control']

            preds['pred'].append(plot_pred_adj1.detach())
            #preds['control'].append(plot_pred_adj2.detach())

            #resids['grid'].append(grid_samp.detach())
            residuals1 = torch.mean(torch.square(residuals1))
            resids['resid'].append(residuals1.detach().cpu().numpy())
            cost_objective1 = torch.mean(torch.square(cost_objective1))
            cost_objective['cost'].append(cost_objective1.detach().cpu().numpy())

        if log:
            print(f'Step {epoch}: G1 Loss: {g_loss1.item():.4e} | D1 Loss: {d_loss1.item():.4e} | cost Loss: {cost_objective1.item():.4e} | Residual Loss: {residuals1.item():.4e}')
    time_end = time.time()
    process_time = time_end - time_start
    print('process time:', process_time)

    if plot:
        pred_dict1, diff_dict1 = problem.get_plot_dicts(G1(plot_grid),G2(plot_x),G2, plot_x, plot_t, plot_soln)
        plot_results_gan(losses1, losses2, G2, plot_grid.detach(), pred_dict1, resids=resids,cost_objective=cost_objective,
                     save=save, dirname=dirname, logloss=False, alpha=0.7, dims=dims,
                     plot_1d_curves=plot_1d_curves)
        plot_3D(plot_grid.detach(), pred_dict1, view=view, dims=dims, save=save, dirname=dirname)
    control = G2(plot_x)
    if save:
        write_config(config, os.path.join(dirname, 'config_GPU.yaml'))
        np.save(os.path.join(dirname, 'gan_residual_GPU'), resids)
        np.save(os.path.join(dirname, 'gan_cost_GPU'), cost_objective)

    # 定义模型保存路径
    model_save_path_G1 = os.path.join(dirname, f'G1_model_GPU.pth')
    # 保存模型
    torch.save(G1, model_save_path_G1)
    model_save_path_G2 = os.path.join(dirname, f'G2_model_GPU.pth')
    # 保存模型
    torch.save(G2, model_save_path_G2)


    return {'model1':G1, 'model2': G2, 'losses1': losses1, 'losses2': losses2, 'cost': cost_objective}


def train_L2_2D(model1,model2, problem, method='unsupervised', niters=100,
                lr=1e-3, betas=(0, 0.9), lr_schedule=True, gamma=0.999, step_size=15,
                obs_every=1, d1=1, d2=1, log=True, plot=True, save=False,
                dirname='train_L2', config=None, loss_fn=None, save_for_animation=False,
                **kwargs):
    """
    Train/test Lagaris method: supervised/semisupervised/unsupervised
    """
    assert method in ['supervised', 'semisupervised', 'unsupervised'], f'Method {method} not understood!'

    dirname = os.path.join(this_dir, '../experiments/runs', dirname)
    if plot and save:
        handle_overwrite(dirname)

    # validation: fixed grid/solution
    x, y = problem.get_grid()
    grid = torch.cat((x, y), 1)
    sol = problem.get_solution(x, y)

    # optimizers & loss functions
    opt1 = torch.optim.Adam(model1.parameters(), lr=lr, betas=betas)
    opt2 = torch.optim.Adam(model2.parameters(), lr=lr, betas=betas)

    if loss_fn:
        mse = eval(f"torch.nn.{loss_fn}()")
    else:
        mse = torch.nn.MSELoss()
    # lr scheduler
    if lr_schedule:
        lr_scheduler1 = torch.optim.lr_scheduler.StepLR(optimizer=opt1, step_size=step_size, gamma=gamma)
        lr_scheduler2 = torch.optim.lr_scheduler.StepLR(optimizer=opt2, step_size=step_size, gamma=gamma)

    loss_trace = []
    cost_objective = {'cost': []}
    residuals = {'resid':[]}

    tolerance_counter = 0
    tolerance_limit = 300
    time_start = time.time()
    for i in range(niters):
        xs, ys = problem.get_grid_sample()
        grid_samp = torch.cat((xs, ys), 1)
        pred1 = model1(grid_samp)
        pred2 = model2(xs)

        xs_mean, ys_mean = problem.get_grid_sample_top_wall()
        grid_samp_mean = torch.cat((xs_mean, ys_mean), 1)
        pred1_mean = model1(grid_samp_mean)
        pred2_mean = model2(xs_mean)

        cost_objective1 = problem.get_cost(pred1_mean, pred2_mean,model2, xs_mean, ys_mean)
        residuals1 = problem.get_equation(pred1, pred2,model2, xs, ys)

        wj = 10000000000
        cost_objective1 = cost_objective1.unsqueeze(0).unsqueeze(0)
        residuals_loss =mse (residuals1, torch.zeros_like(residuals1))
        cost_loss = mse(cost_objective1, torch.zeros_like(cost_objective1))
        loss = residuals_loss + wj*cost_loss
        loss_trace.append(loss.item())

        opt1.zero_grad()
        opt2.zero_grad()
        loss.backward(retain_graph=True)
        opt1.step()
        opt2.step()
        if lr_schedule:
            lr_scheduler1.step()
            lr_scheduler2.step()

        residuals['resid'].append(residuals_loss.detach())
        cost_objective['cost'].append(cost_loss.detach())
        if log:
            print(f'Step {i}: Loss: {loss.item():.4e} |  Cost: {cost_loss.item():.4e} |  Residuals: {residuals_loss.item():.4e}')

        resid_i = residuals['resid'][i-1]
        resid_i_plus_1 = residuals['resid'][i]

        if abs(resid_i - resid_i_plus_1) < 1e-14:
            tolerance_counter += 1  # 增加计数器
        else:
            tolerance_counter *= 0  # 误差不满足条件时重置计数器

        if tolerance_counter >= tolerance_limit:
            break  # 终止当前迭代，开始下一次迭代
    time_end = time.time()
    process_time = time_end - time_start
    print('process time:', process_time)

    if plot:
        loss_dict = {}
        if method == 'supervised':
            loss_dict['$L_S$'] = loss_trace
        elif method == 'semisupervised':
            loss_dict['$L_S$'] = [l[0] for l in loss_trace]
            loss_dict['$L_U$'] = [l[1] for l in loss_trace]
        else:
            loss_dict['$L_U$'] = loss_trace
        dims = problem.get_plot_dims()

        save_to = os.path.join(this_dir, '../experiments/runs', dirname)

        x_plot, y_plot = problem.get_plot_grid()
        grid_plot = torch.cat((x_plot, y_plot), 1)
        sol_plot = problem.get_plot_solution(x_plot, y_plot)
        pred_dict, diff_dict = problem.get_plot_dicts(model1(grid_plot),model2(x_plot),model2, x_plot, y_plot, sol_plot)
        plot_results_L2(wj,model1, model2, loss_dict, pred_dict, grid_plot.detach(), diff_dict=diff_dict, residuals = residuals,
                    cost_objective=cost_objective,save=save, dirname=dirname, logloss=True, alpha=0.8,
                    dims=dims)
    a = torch.linspace(0,1,1000).reshape(-1,1)
    if save:
        write_config(config, os.path.join(dirname, 'config.yaml'))
        np.save(os.path.join(dirname, f'hard_residual_{wj}'), residuals)
        np.save(os.path.join(dirname, f'hard_cost_{wj}'), cost_objective)

    if save_for_animation:
        if not os.path.exists(dirname):
            os.mkdir(dirname)
        anim_dir = os.path.join(dirname, "animation")
        print(f'Saving animation traces to {anim_dir}')
        if not os.path.exists(anim_dir):
            os.mkdir(anim_dir)
    return {'model1': model1, 'model2': model2, 'losses': loss_trace}

def train_L2_2D_soft(model1,model2, problem, method='unsupervised', niters=100,
                lr=1e-3, betas=(0, 0.9), lr_schedule=True, gamma=0.999, step_size=15,
                obs_every=1, d1=1, d2=1, log=True, plot=True, save=False,
                dirname='train_L2', config=None, loss_fn=None, save_for_animation=False,
                **kwargs):
    """
    Train/test Lagaris method: supervised/semisupervised/unsupervised
    """
    assert method in ['supervised', 'semisupervised', 'unsupervised'], f'Method {method} not understood!'

    dirname = os.path.join(this_dir, '../experiments/runs', dirname)
    if plot and save:
        handle_overwrite(dirname)

    # validation: fixed grid/solution
    x, y = problem.get_grid()

    grid = torch.cat((x, y), 1)
    sol = problem.get_solution(x, y)

    # optimizers & loss functions
    opt1 = torch.optim.Adam(model1.parameters(), lr=lr, betas=betas)
    opt2 = torch.optim.Adam(model2.parameters(), lr=lr, betas=betas)

    if loss_fn:
        mse = eval(f"torch.nn.{loss_fn}()")
    else:
        mse = torch.nn.MSELoss()
    # lr scheduler
    if lr_schedule:
        lr_scheduler1 = torch.optim.lr_scheduler.StepLR(optimizer=opt1, step_size=step_size, gamma=gamma)
        lr_scheduler2 = torch.optim.lr_scheduler.StepLR(optimizer=opt2, step_size=step_size, gamma=gamma)

    loss_trace = []
    cost_objective = {'cost': []}
    residuals = {'resid':[], 'bound':[], 'ini':[]}
    #mses = {'train': [], 'val': []}
    preds = {'pred': [], 'soln': []}

    tolerance_counter = 0
    tolerance_limit = 300
    time_start = time.time()
    for i in range(niters):
        xs, ys = problem.get_grid_sample()  # TODO: remove these unnecessary args
        x_ub, y_ub = problem.get_grid_sample_ub()
        x_lb, y_lb = problem.get_grid_sample_lb()
        x_ini, y_ini = problem.get_grid_sample_ini()
        x_top,y_top = problem.get_grid_sample_top_wall()

        grid_samp = torch.cat((xs, ys), 1)
        grid_samp_ub = torch.cat((x_ub, y_ub), 1)
        grid_samp_lb = torch.cat((x_lb, y_lb), 1)
        grid_samp_ini = torch.cat((x_ini, y_ini), 1)
        grid_samp_top = torch.cat((x_top, y_top), 1)

        pred1 = model1(grid_samp)
        pred1_top_bound = model1(grid_samp_top)
        pred2_top_bound = model2(x_top)
        pred1_ub = model1(grid_samp_ub)
        pred1_lb = model1(grid_samp_lb)
        pred1_ini = model1(grid_samp_ini)
        pred1_cost = model1(grid_samp_top)
        residuals1 = problem._laplace_eqn(pred1, xs, ys)
        cost_objective1 = problem.get_cost_soft(pred1_cost, x_top, y_top)
        cost_objective1 = cost_objective1.unsqueeze(0).unsqueeze(0)

        residuals_loss = mse(residuals1, torch.zeros_like(residuals1))
        cost_loss = mse(cost_objective1, torch.zeros_like(cost_objective1))
        ub_loss = mse(pred1_ub, torch.zeros_like(pred1_ub))
        lb_loss = mse(pred1_lb, torch.zeros_like(pred1_lb))
        ini_loss = mse(pred1_ini, torch.sin(torch.tensor(np.pi)*x_ini))
        #top_loss = mse(pred1_top_bound-pred2_top_bound, torch.zeros_like(pred1_top_bound))
        top_loss = mse(pred1_top_bound, pred2_top_bound)

        wj = 10000000000
        bound_loss = ub_loss + lb_loss +top_loss
        loss = residuals_loss + bound_loss + ini_loss  +wj* cost_loss
        loss_trace.append(loss.item())

        opt1.zero_grad()
        opt2.zero_grad()
        loss.backward(retain_graph=True)
        opt1.step()
        opt2.step()
        if lr_schedule:
            lr_scheduler1.step()
            lr_scheduler2.step()

        #residuals1 = torch.mean(torch.square(residuals1))
        residuals['resid'].append(residuals_loss.detach())
        #cost_objective1 = torch.mean(torch.square(cost_objective1))
        cost_objective['cost'].append(cost_loss.detach())
        residuals['bound'].append(bound_loss.detach())
        residuals['ini'].append(ini_loss.detach())

        if log:
            print(f'Step {i}: Loss: {loss.item():.4e} |  Cost: {cost_loss.item():.4e} |  Residuals: {residuals_loss.item():.4e}'
                  f'|  Ini: {ini_loss.item():.4e} |  Bound: {bound_loss.item():.4e} ')

        resid_i = residuals['resid'][i-1]
        resid_i_plus_1 = residuals['resid'][i]

        if abs(resid_i - resid_i_plus_1) < 1e-14:
            tolerance_counter += 1  # 增加计数器
        else:
            tolerance_counter *= 0  # 误差不满足条件时重置计数器

        if tolerance_counter >= tolerance_limit:
            break  # 终止当前迭代，开始下一次迭代

    time_end = time.time()
    process_time = time_end - time_start
    print('process time:', process_time)
    if plot:
        loss_dict = {}
        if method == 'supervised':
            loss_dict['$L_S$'] = loss_trace
        elif method == 'semisupervised':
            loss_dict['$L_S$'] = [l[0] for l in loss_trace]
            loss_dict['$L_U$'] = [l[1] for l in loss_trace]
        else:
            loss_dict['$L_U$'] = loss_trace
        dims = problem.get_plot_dims()

        save_to = os.path.join(this_dir, '../experiments/runs', dirname)

        x_plot, y_plot = problem.get_plot_grid()
        grid_plot = torch.cat((x_plot, y_plot), 1)
        sol_plot = problem.get_plot_solution(x_plot, y_plot)
        pred_dict, diff_dict = problem.get_plot_dicts_soft(model1(grid_plot),model2(x_plot), x_plot, y_plot, sol_plot)
        plot_results_L2(wj,model1,model2, loss_dict, pred_dict, grid_plot.detach(), diff_dict=diff_dict, residuals = residuals,
                    cost_objective=cost_objective,save=save, dirname=dirname, logloss=True, alpha=0.8,
                    dims=dims)
    a = torch.linspace(0,1,500).reshape(-1,1)
    if save:
        write_config(config, os.path.join(dirname, 'config.yaml'))
        np.save(os.path.join(dirname, f'soft_residual_{wj}'), residuals)
        np.save(os.path.join(dirname, f'soft_cost_{wj}'), cost_objective)

    if save_for_animation:
        if not os.path.exists(dirname):
            os.mkdir(dirname)
        anim_dir = os.path.join(dirname, "animation")
        print(f'Saving animation traces to {anim_dir}')
        if not os.path.exists(anim_dir):
            os.mkdir(anim_dir)

    return {'model1': model1, 'model2': model2, 'losses': loss_trace}

def train_LuLu_penalty(model1,model2, problem, method='unsupervised', niters=100,
                lr=1e-3, betas=(0, 0.9), lr_schedule=True, gamma=0.999, step_size=15,
                obs_every=1, d1=1, d2=1, log=True, plot=True, save=False,
                dirname='train_L2', config=None, loss_fn=None, save_for_animation=False,
                **kwargs):
    """
    Train/test Lagaris method: supervised/semisupervised/unsupervised
    """
    assert method in ['supervised', 'semisupervised', 'unsupervised'], f'Method {method} not understood!'

    dirname = os.path.join(this_dir, '../experiments/runs', dirname)
    if plot and save:
        handle_overwrite(dirname)

    # validation: fixed grid/solution
    x, y = problem.get_grid()
    grid = torch.cat((x, y), 1)
    sol = problem.get_solution(x, y)

    # optimizers & loss functions
    opt1 = torch.optim.Adam(model1.parameters(), lr=lr, betas=betas)
    opt2 = torch.optim.Adam(model2.parameters(), lr=lr, betas=betas)

    if loss_fn:
        mse = eval(f"torch.nn.{loss_fn}()")
    else:
        mse = torch.nn.MSELoss()
    # lr scheduler
    if lr_schedule:
        lr_scheduler1 = torch.optim.lr_scheduler.StepLR(optimizer=opt1, step_size=step_size, gamma=gamma)
        lr_scheduler2 = torch.optim.lr_scheduler.StepLR(optimizer=opt2, step_size=step_size, gamma=gamma)

    loss_trace = []
    cost_objective = {'cost': []}
    residuals = {'resid':[]}
    j = 0
    wj = 1e-5
    beta = 10
    a = 1e-4

    tolerance_counter = 0
    tolerance_limit = 300
    time_start = time.time()
    for i in range(niters):
        xs, ys = problem.get_grid_sample()
        grid_samp = torch.cat((xs, ys), 1)
        pred1 = model1(grid_samp)
        pred2 = model2(xs)

        xs_mean, ys_mean = problem.get_grid_sample_top_wall()
        grid_samp_mean = torch.cat((xs_mean, ys_mean), 1)
        pred1_mean = model1(grid_samp_mean)
        pred2_mean = model2(xs_mean)

        cost_objective1 = problem.get_cost(pred1_mean, pred2_mean,model2, xs_mean, ys_mean)
        residuals1 = problem.get_equation(pred1, pred2,model2, xs, ys)

        cost_objective1 = cost_objective1.unsqueeze(0).unsqueeze(0)
        residuals_loss =mse (residuals1, torch.zeros_like(residuals1))
        cost_loss = mse(cost_objective1, torch.zeros_like(cost_objective1))
        loss = wj*residuals_loss + cost_loss
        loss_trace.append(loss.item())

        opt1.zero_grad()
        opt2.zero_grad()
        loss.backward(retain_graph=True)
        opt1.step()
        opt2.step()
        if lr_schedule:
            lr_scheduler1.step()
            lr_scheduler2.step()

        residuals['resid'].append(residuals_loss.detach())
        cost_objective['cost'].append(cost_loss.detach())
        if log:
            print(f'Step {i}: Loss: {loss.item():.4e} |  Cost: {cost_loss.item():.4e} |  Residuals: {residuals_loss.item():.4e}')

        resid_i = residuals['resid'][i-1]
        resid_i_plus_1 = residuals['resid'][i]

        if abs(resid_i - resid_i_plus_1) < a:
            tolerance_counter += 1  # 增加计数器
        else:
            tolerance_counter *= 0  # 误差不满足条件时重置计数器

        if tolerance_counter >= tolerance_limit:
            a = a * 1e-2
            tolerance_counter = 0
            wj = wj * beta  # 终止当前迭代，开始下一次迭代
            j = j + 1
            print(j)
            print(tolerance_counter)

        if j >= 5:
            print(wj)
            break
    time_end = time.time()
    process_time = time_end - time_start
    print('process time:', process_time)

    if plot:
        loss_dict = {}
        if method == 'supervised':
            loss_dict['$L_S$'] = loss_trace
        elif method == 'semisupervised':
            loss_dict['$L_S$'] = [l[0] for l in loss_trace]
            loss_dict['$L_U$'] = [l[1] for l in loss_trace]
        else:
            loss_dict['$L_U$'] = loss_trace
        dims = problem.get_plot_dims()

        save_to = os.path.join(this_dir, '../experiments/runs', dirname)

        x_plot, y_plot = problem.get_plot_grid()
        grid_plot = torch.cat((x_plot, y_plot), 1)
        sol_plot = problem.get_plot_solution(x_plot, y_plot)
        pred_dict, diff_dict = problem.get_plot_dicts(model1(grid_plot),model2(x_plot),model2, x_plot, y_plot, sol_plot)
        plot_lulu_penalty(wj,model1, model2, loss_dict, pred_dict, grid_plot.detach(), diff_dict=diff_dict, residuals = residuals,
                    cost_objective=cost_objective,save=save, dirname=dirname, logloss=True, alpha=0.8,
                    dims=dims)
    a = torch.linspace(0,1,1000).reshape(-1,1)
    if save:
        write_config(config, os.path.join(dirname, 'lulu_penalty.yaml'))
        np.save(os.path.join(dirname, f'lulu_penalty_residual_{wj}'), residuals)
        np.save(os.path.join(dirname, f'lulu_penalty_cost_{wj}'), cost_objective)

    # 定义模型保存路径
    model_save_path_model1 = os.path.join(dirname, f'lulu_penalty_model1_{wj}.pth')
    # 保存模型
    torch.save(model1, model_save_path_model1)
    model_save_path_model2 = os.path.join(dirname, f'lulu_penalty_model2_{wj}.pth')
    # 保存模型
    torch.save(model2, model_save_path_model2)

    return {'model1': model1, 'model2': model2, 'losses': loss_trace}

def train_LuLu_augment(model1,model2, problem, method='unsupervised', niters=100,
                lr=1e-3, betas=(0, 0.9), lr_schedule=True, gamma=0.999, step_size=15,
                obs_every=1, d1=1, d2=1, log=True, plot=True, save=False,
                dirname='train_L2', config=None, loss_fn=None, save_for_animation=False,
                **kwargs):
    """
    Train/test Lagaris method: supervised/semisupervised/unsupervised
    """
    assert method in ['supervised', 'semisupervised', 'unsupervised'], f'Method {method} not understood!'

    dirname = os.path.join(this_dir, '../experiments/runs', dirname)
    if plot and save:
        handle_overwrite(dirname)

    # validation: fixed grid/solution
    x, y = problem.get_grid()
    grid = torch.cat((x, y), 1)
    sol = problem.get_solution(x, y)

    # optimizers & loss functions
    opt1 = torch.optim.Adam(model1.parameters(), lr=lr, betas=betas)
    opt2 = torch.optim.Adam(model2.parameters(), lr=lr, betas=betas)

    if loss_fn:
        mse = eval(f"torch.nn.{loss_fn}()")
    else:
        mse = torch.nn.MSELoss()
    # lr scheduler
    if lr_schedule:
        lr_scheduler1 = torch.optim.lr_scheduler.StepLR(optimizer=opt1, step_size=step_size, gamma=gamma)
        lr_scheduler2 = torch.optim.lr_scheduler.StepLR(optimizer=opt2, step_size=step_size, gamma=gamma)

    loss_trace = []
    cost_objective = {'cost': []}
    residuals = {'resid':[]}
    j = 0
    wj = 1e-5
    beta = 10
    Lambda = torch.zeros(33 * 33).reshape(-1, 1)
    a = 1e-4
    tolerance_counter = 0
    tolerance_limit = 300
    time_start = time.time()
    for i in range(niters):
        xs, ys = problem.get_grid_sample()
        grid_samp = torch.cat((xs, ys), 1)
        pred1 = model1(grid_samp)
        pred2 = model2(xs)

        xs_mean, ys_mean = problem.get_grid_sample_top_wall()
        grid_samp_mean = torch.cat((xs_mean, ys_mean), 1)
        pred1_mean = model1(grid_samp_mean)
        pred2_mean = model2(xs_mean)

        cost_objective1 = problem.get_cost(pred1_mean, pred2_mean,model2, xs_mean, ys_mean)
        residuals1 = problem.get_equation(pred1, pred2,model2, xs, ys)
        residuals2 = problem.get_equation(pred1, pred2,model2, xs, ys)

        cost_objective1 = cost_objective1.unsqueeze(0).unsqueeze(0)
        residuals_loss =mse (residuals1, torch.zeros_like(residuals1))
        cost_loss = mse(cost_objective1, torch.zeros_like(cost_objective1))
        loss = wj*residuals_loss + cost_loss + torch.mean(Lambda * residuals1)
        loss_trace.append(loss.item())

        opt1.zero_grad()
        opt2.zero_grad()
        loss.backward(retain_graph=True)
        opt1.step()
        opt2.step()
        if lr_schedule:
            lr_scheduler1.step()
            lr_scheduler2.step()

        residuals['resid'].append(residuals_loss.detach())
        cost_objective['cost'].append(cost_loss.detach())
        if log:
            print(f'Step {i}: Loss: {loss.item():.4e} |  Cost: {cost_loss.item():.4e} |  Residuals: {residuals_loss.item():.4e}')

        resid_i = residuals['resid'][i-1]
        resid_i_plus_1 = residuals['resid'][i]

        if abs(resid_i - resid_i_plus_1) < a:
            tolerance_counter += 1  # 增加计数器
        else:
            tolerance_counter *= 0  # 误差不满足条件时重置计数器

        if tolerance_counter >= tolerance_limit:
            a = a * 1e-2
            tolerance_counter = 0
            wj = wj * beta  # 终止当前迭代，开始下一次迭代
            j = j + 1
            Lambda = Lambda + wj * 2 * residuals2.detach()
            print(j)

        if j >= 5:
            print(wj)
            break
    time_end = time.time()
    process_time = time_end - time_start
    print('process time:', process_time)

    if plot:
        loss_dict = {}
        if method == 'supervised':
            loss_dict['$L_S$'] = loss_trace
        elif method == 'semisupervised':
            loss_dict['$L_S$'] = [l[0] for l in loss_trace]
            loss_dict['$L_U$'] = [l[1] for l in loss_trace]
        else:
            loss_dict['$L_U$'] = loss_trace
        dims = problem.get_plot_dims()

        save_to = os.path.join(this_dir, '../experiments/runs', dirname)

        x_plot, y_plot = problem.get_plot_grid()
        grid_plot = torch.cat((x_plot, y_plot), 1)
        sol_plot = problem.get_plot_solution(x_plot, y_plot)
        pred_dict, diff_dict = problem.get_plot_dicts(model1(grid_plot),model2(x_plot),model2, x_plot, y_plot, sol_plot)
        plot_lulu_augment(wj,model1, model2, loss_dict, pred_dict, grid_plot.detach(), diff_dict=diff_dict, residuals = residuals,
                    cost_objective=cost_objective,save=save, dirname=dirname, logloss=True, alpha=0.8,
                    dims=dims)
    if save:
        write_config(config, os.path.join(dirname, 'lulu_augment_config.yaml'))
        np.save(os.path.join(dirname, f'lulu_augment_residual_{wj}'), residuals)
        np.save(os.path.join(dirname, f'lulu_augment_cost_{wj}'), cost_objective)

    # 定义模型保存路径
    model_save_path_model1 = os.path.join(dirname, f'lulu_augment_model1_{wj}.pth')
    # 保存模型
    torch.save(model1, model_save_path_model1)
    model_save_path_model2 = os.path.join(dirname, f'lulu_augment_model2_{wj}.pth')
    # 保存模型
    torch.save(model2, model_save_path_model2)

    return {'model1': model1, 'model2': model2, 'losses': loss_trace}