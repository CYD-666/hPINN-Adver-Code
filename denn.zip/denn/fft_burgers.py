import numpy as np
from scipy.integrate import odeint
import torch
def fft_burgers(x, t, nu, u_ini):
    xmin, xmax = np.min(x), np.max(x)
    nx, nt = len(x), len(t)
    dx = (xmax - xmin)/nx

    kappa = 2*np.pi*np.fft.fftfreq(nx, d=dx)
    u0 = np.asarray(u_ini).ravel()
    #u0 = np.sin(x*np.pi)
    #print(u0)
    def rhsBurgers(u, t, kappa, nu):

        uhat = np.fft.fft(u)
        d_uhat = (1j)*kappa*uhat
        dd_uhat = -np.power(kappa, 2)*uhat
        d_u = np.fft.ifft(d_uhat)
        dd_u = np.fft.ifft(dd_uhat)
        du_dt = -u*d_u + nu*dd_u
        return du_dt.real

    u = odeint(rhsBurgers, u0, t, args=(kappa, nu))

    return u

def fft_burgers_dis(x, t, nu):
    xmin, xmax = np.min(x), np.max(x)
    nx, nt = len(x), len(t)
    dx = (xmax - xmin)/nx
    kappa = 2*np.pi*np.fft.fftfreq(nx, d=dx)
    u0 = np.sin(np.pi*x)
    def rhsBurgers(u, t, kappa, nu):

        uhat = np.fft.fft(u)
        d_uhat = (1j)*kappa*uhat
        dd_uhat = -np.power(kappa, 2)*uhat
        d_u = np.fft.ifft(d_uhat)
        dd_u = np.fft.ifft(dd_uhat)
        du_dt = -u*d_u + nu*dd_u
        return du_dt.real

    u = odeint(rhsBurgers, u0, t, args=(kappa, nu))

    return u

if __name__ == "__main__":

    import matplotlib.pyplot as plt

    u = fft_burgers_dis(np.linspace(-1,1,128), np.linspace(0,2,128), 0.01/np.pi)
    print(u.shape)

    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')

    u_plot = u[0:-1:10,:]
    for j in range(u_plot.shape[0]):
        ys = j*np.ones(u_plot.shape[1])
        ax.plot(np.linspace(-1,1,128),ys,u_plot[j,:])

    plt.figure()
    plt.imshow(np.flipud(u), aspect=8)
    plt.axis('off')
    plt.show()