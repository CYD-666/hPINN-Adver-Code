import os
from matplotlib import lines
import torch
from torch import autograd
import numpy as np
import itertools
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib import cm
from IPython.display import clear_output
import pandas as pd 
import scipy.sparse as sp
from scipy.sparse.linalg import spsolve
from denn.fft_burgers import fft_burgers

# global plot params
plt.rc('axes', titlesize=18, labelsize=18)
plt.rc('legend', fontsize=16)
plt.rc('xtick', labelsize=18)
plt.rc('ytick', labelsize=18)
# plt.rcParams['text.usetex'] = True

def diff(x, t, order=1):
    """The derivative of a variable with respect to another.
    :param x: The :math:`x` in :math:`\\displaystyle\\frac{\\partial x}{\\partial t}`.
    :type x: `torch.tensor`
    :param t: The :math:`t` in :math:`\\displaystyle\\frac{\\partial x}{\\partial t}`.
    :type t: `torch.tensor`
    :param order: The order of the derivative, defaults to 1.
    :type order: int
    :returns: The derivative.
    :rtype: `torch.tensor`
    """
    ones = torch.ones_like(x)
    der, = autograd.grad(x, t, create_graph=True, grad_outputs=ones)
    for i in range(1, order):
        ones = torch.ones_like(der)
        der, = autograd.grad(der, t, create_graph=True, grad_outputs=ones)
    return der

'''def plot_results(mse_dict, loss_dict, grid, pred_dict, diff_dict=None, clear=False,
    save=False, dirname=None, logloss=False, alpha=0.8, plot_sep_curves=False, 
    dims=None, plot_1d_curves=False):'''
def plot_results_gan(loss_dict1,loss_dict2, G1, G2, grid, pred_dict1, resids=None,cost_objective = None, clear=False,
                save=False, dirname=None, logloss=True, alpha=0.8, plot_sep_curves=False,
                dims=None, plot_1d_curves=False):

    plt.rc('axes', titlesize=20, labelsize=20)
    plt.rc('legend', fontsize=16)
    plt.rc('xtick', labelsize=18)
    plt.rc('ytick', labelsize=18)
    # plt.rcParams['text.usetex'] = True

    if clear:
      clear_output(True)

    if save and not dirname:
        raise RuntimeError('Please provide a directory name `dirname` when `save=True`.')

    if plot_sep_curves:
        n_curves = int(len(pred_dict1.keys())/2)
        fig, ax = plt.subplots(2, n_curves+1, figsize=(8*(n_curves+1), 8))
    elif plot_1d_curves:
        fig, ax = plt.subplots(3, 3, figsize=(32, 30))
        ax = ax.ravel()
    else:
        if resids:   # add derivatives plot
            fig, ax = plt.subplots(1, 4, figsize=(16, 4))
        else:
            fig, ax = plt.subplots(1, 3, figsize=(12, 4))

    linestyles = ['solid', 'dashed', 'dashdot', 'dotted']*3
    linewidth = 2
    alphas = [alpha]*10
    colors = ['crimson', 'blue', 'skyblue', 'limegreen',
        'aquamarine', 'violet', 'black', 'brown', 'pink', 'gold']

    # Losses
    for i, (k, v) in enumerate(loss_dict1.items()):
        if plot_sep_curves:
            ax[0][0].plot(np.arange(len(v)), v, label=k,
                alpha=alphas[i], linewidth=linewidth, color=colors[i],
                linestyle=linestyles[i])
        else:
            ax[0].plot(np.arange(len(v)), v, label=k,
                alpha=alphas[i], linewidth=linewidth, color=colors[i],
                linestyle=linestyles[i])

    for i, (k, v) in enumerate(loss_dict2.items()):
        if plot_sep_curves:
            ax[1][0].plot(np.arange(len(v)), v, label=k,
                alpha=alphas[i], linewidth=linewidth, color=colors[i],
                linestyle=linestyles[i])
        else:
            ax[1].plot(np.arange(len(v)), v, label=k,
                alpha=alphas[i], linewidth=linewidth, color=colors[i],
                linestyle=linestyles[i])

    if plot_sep_curves:
        if len(loss_dict1.keys()) > 1: # only add legend if > 1 curves
            ax[0][0].legend(loc='upper right')
        ax[0][0].set_xlabel('Iteration')
        ax[0][0].set_ylabel('Loss')
        if logloss:
            ax[0][0].set_yscale('log')
    else:
        if len(loss_dict1.keys()) > 1: # only add legend if > 1 curves
            ax[0].legend(loc='upper right')
        ax[0].set_xlabel('Iteration')
        ax[0].set_ylabel('Loss')
        if logloss:
            ax[0].set_yscale('log')

    if plot_sep_curves:
        if len(loss_dict2.keys()) > 1: # only add legend if > 1 curves
            ax[1][0].legend(loc='upper right')
        ax[1][0].set_xlabel('Iteration')
        ax[1][0].set_ylabel('Loss')
        if logloss:
            ax[1][0].set_yscale('log')
    else:
        if len(loss_dict2.keys()) > 1: # only add legend if > 1 curves
            ax[1].legend(loc='upper right')
        ax[1].set_xlabel('Iteration')
        ax[1].set_ylabel('Loss')
        if logloss:
            ax[1].set_yscale('log')

    # Predictions
    if grid.shape[1] == 2: # PDE
        x, y = grid[:, 0], grid[:, 1]
        xdim, ydim = dims.values()
        xx, yy = x.reshape((xdim, ydim)), y.reshape((xdim, ydim))
        for i, (k, v) in enumerate(pred_dict1.items()):
            v = v.reshape((xdim, ydim))
            cf = ax[2].contourf(xx.cpu().numpy(), yy.cpu().numpy(), v.cpu().numpy(), 10, cmap='RdYlBu')
            cb = fig.colorbar(cf, ax=ax[2])
            break
        xlab, ylab = dims.keys()
        ax[2].set_xlabel(f'${xlab}$')
        ax[2].set_ylabel(f'${ylab}$')
        ax[2].set_title('GAN-PINN')
    else: # ODE
        if plot_sep_curves:
            for i, (k, v) in enumerate(pred_dict1.items()):
                if i%2 == 0:
                    plot_id = int((i/2)+1)
                    style_id = 0
                else:
                    style_id = 1
                ax[0][plot_id].plot(grid, v, label=k, 
                alpha=alphas[style_id], linestyle=linestyles[style_id], 
                linewidth=linewidth, color=colors[style_id])
                ax[0][plot_id].set_xlabel('$t$')
                ax[0][plot_id].set_ylabel(k)
                ax[0][plot_id].legend()
        else:
            for i, (k, v) in enumerate(pred_dict1.items()):
                ax[2].plot(grid, v, label=k,
                    alpha=alphas[i], linestyle=linestyles[i],
                    linewidth=linewidth, color=colors[i])
            ax[2].set_xlabel('$t$')
            ax[2].set_ylabel('$x$')
            if len(pred_dict1.keys()) > 1:
                ax[2].legend(loc='upper right')

    # 1-dimensional curves for PDE 在 plot_results 函数中，有一个选项 plot_1d_curves
    # 专门用于绘制偏微分方程（PDE）的一维曲线。这些曲线通过在不同时间点提取数据来显示 PDE 解决
    # 方案在特定时间点随空间变量变化的情况。
    #画出C-N格式的解：
    if grid.shape[1] == 2: # PDE
        L = 1  # 空间范围
        T = 1  # 时间范围
        pi = torch.tensor(torch.pi)
        T = torch.tensor(T)
        Nx = 128  # 空间步数
        Nt = 128  # 时间步数
        dx = L / (Nx - 1)
        dt = T / (Nt - 1)
        # 生成 x 和 t 的网格节点
        x_values = torch.linspace(0, L, Nx).reshape(-1,1)
        t_values_f = torch.linspace(0, T, Nt).reshape(-1,1)
        t_values = T * torch.ones_like(x_values).reshape(-1,1)
        plot_grid = torch.cat((x_values, t_values), 1)
        # 创建网格
        f_damp = G2(t_values_f)
        a = np.linspace(0, L, Nx)

        #real_solu = 2*torch.sin(2*pi*t_values_f)/(t_values_f + 1)
        real_solu = t_values_f + 1
        #real_solu = (t_values_f + 1)**2

        ax[5].plot(a, f_damp.detach().cpu().numpy(), label="$\hat{u}$",
                   alpha=alphas[0], linewidth=linewidth, color=colors[1],
                   linestyle=linestyles[0])
        ax[5].plot(a, real_solu.cpu(), label="$u$",
                    alpha=alphas[0], linewidth=linewidth, color=colors[0],
                    linestyle=linestyles[1])
        ax[5].set_xlabel('x')
        ax[5].set_ylabel('u(x,0)')
        ax[5].set_title('Optimal control(Initial condition)')
        ax[5].legend(loc='upper right')

        diff_squared_error = torch.square(f_damp - real_solu)
        diff_squared = torch.square(real_solu)
        relative_l2_error = torch.sqrt(torch.sum(diff_squared_error))
        relative_l2 = torch.sqrt(torch.sum(diff_squared))
        relative = relative_l2_error / relative_l2
        print('Control Relative L2 error: ', relative)

        ax[6].plot(a,  np.abs((real_solu - f_damp).detach().cpu().numpy()), label="$|\hat{u}-u|$",
                   alpha=alphas[0], linewidth=linewidth, color=colors[0],
                   linestyle=linestyles[1])
        ax[6].set_xlabel('x')
        ax[6].set_ylabel("$|\hat{u}-u|$")
        ax[6].set_title('State at top wall')
        ax[6].legend(loc='upper right')
        
        real_solu_final = (x_values+1)/2+4/3
        #real_solu_final = (x_values+1)/2-1/(2*pi)
        #real_solu_final = (x_values + 1) / 2 + 2

        x_min_val = lambda t: 1 / (t + 1) + 1 / 3 * (t + 1) ** 2
        x_max_val = lambda t: 2 / (t + 1) + 1 / 3 * (t + 1) ** 2
        t_min_val = lambda x: x + 4 / 3

        #x_min_val = lambda t: 1 / (t + 1) - torch.cos(2 * pi * t) / (t + 1) / pi
        #x_max_val = lambda t: 2 / (t + 1) - torch.cos(2 * pi * t) / (t + 1) / pi
        #t_min_val = lambda x: x + 1 - 1 / pi

        #x_min_val = lambda t: 1 / (t + 1) + 1 / 4 * (t + 1) ** 3
        #x_max_val = lambda t: 2 / (t + 1) + 1 / 4 * (t + 1) ** 3
        #t_min_val = lambda x: x + 1 + 1/4

        xmin = 0
        xmax = 1
        Axy = (1 - x_values) * x_min_val(t_values) + x_values * x_max_val(t_values) + \
              (1 - t_values) * (t_min_val(x_values) - ((1 - x_values) * t_min_val(xmin * torch.ones_like(x_values))
                                                    + x_values * t_min_val(xmax * torch.ones_like(x_values))))
        f_final_u = Axy + x_values*(1-x_values)*(1 - torch.exp(- t_values/T)) * G1(plot_grid)

        ax[7].plot(a, real_solu_final.cpu().numpy(), label="$u$",
                   alpha=alphas[0], linewidth=linewidth, color=colors[0],
                   linestyle=linestyles[1])
        ax[7].set_xlabel('x')
        ax[7].set_ylabel('u(x,1)')
        ax[7].set_title('Final state')
        ax[7].legend(loc='upper right')
        #print(f_final.shpae)
        #print(real_solu_final.shape)
        a = torch.linspace(0, L, Nx)
        #print(real_solu_final.detach().numpy())
        #print(f_final.detach().numpy())
        #print(real_solu_final.detach() - f_final.detach())
        ax[8].plot(a.cpu(), f_final_u.detach().cpu().numpy(), label="$|\hat{u}-u|$",
                   alpha=alphas[0], linewidth=linewidth, color=colors[0],
                   linestyle=linestyles[1])
        ax[8].set_xlabel('x')
        ax[8].set_ylabel("$|\hat{u}-u|$")
        ax[8].set_title('Final state')
        ax[8].legend(loc='upper right')
        ###########################################################
        # 创建空间和时间网格
        # 绘制图形

    # Derivatives
    if resids:
        for i, (k, v) in enumerate(resids.items()):
            if plot_sep_curves:
                ax[0][3].plot(np.arange(len(v)), v, label=k,
                              alpha=alphas[i], linewidth=linewidth, color=colors[i],
                              linestyle=linestyles[i])
                ax[0][3].set_yscale('log')
                ax[0][3].set_xlabel('Iteration')
                ax[0][3].set_ylabel('Residual')
                ax[0][3].legend(loc='upper right')

            else:
                if isinstance(v, list):
                    v = torch.tensor(v)
                ax[3].plot(np.arange(len(v)), v.cpu(), label=k,
                           alpha=alphas[i], linewidth=linewidth, color=colors[i],
                           linestyle=linestyles[i])
                ax[3].set_yscale('log')
                ax[3].set_xlabel('Iteration')
                ax[3].set_ylabel('Residual')
                ax[3].legend(loc='upper right')

    if cost_objective:
        for i, (k, v) in enumerate(cost_objective.items()):
            if plot_sep_curves:
                ax[0][4].plot(np.arange(len(v)), v, label=k,
                              alpha=alphas[i], linewidth=linewidth, color=colors[i],
                              linestyle=linestyles[i])
                ax[0][4].set_yscale('log')
                ax[0][4].set_xlabel('Iteration')
                ax[0][4].set_ylabel('Cost_objective')
                ax[0][4].legend(loc='upper right')

            else:
                if isinstance(v, list):
                    v = torch.tensor(v)
                ax[4].plot(np.arange(len(v)), v.cpu(), label=k,
                           alpha=alphas[i], linewidth=linewidth, color=colors[i],
                           linestyle=linestyles[i])
                ax[4].set_yscale('log')
                ax[4].set_xlabel('Iteration')
                ax[4].set_ylabel('Cost_objective')
                ax[4].legend(loc='upper right')

    if save:
        print(f'Saving results to {dirname}')
        if not os.path.exists(dirname):
            os.mkdir(dirname)
        plt.savefig(os.path.join(dirname, 'gan_plot_final_GPU.png'), bbox_inches='tight', dpi=300)
        for k, v in loss_dict1.items():
            np.save(os.path.join(dirname, f"{k}_loss_GPU"), v)
        for k, v in loss_dict2.items():
            np.save(os.path.join(dirname, f"{k}_loss_GPU"), v)
    else:
        plt.show()


def plot_results_gan_fs(lambdas,cost_result, loss_dict1, loss_dict2, G1, G2, grid, pred_dict1, resids=None, cost_objective=None, clear=False,
                     save=False, dirname=None, logloss=True, alpha=0.8, plot_sep_curves=False,
                     dims=None, plot_1d_curves=False):
    plt.rc('axes', titlesize=20, labelsize=20)
    plt.rc('legend', fontsize=16)
    plt.rc('xtick', labelsize=18)
    plt.rc('ytick', labelsize=18)
    # plt.rcParams['text.usetex'] = True

    if clear:
        clear_output(True)

    if save and not dirname:
        raise RuntimeError('Please provide a directory name `dirname` when `save=True`.')

    if plot_sep_curves:
        n_curves = int(len(pred_dict1.keys()) / 2)
        fig, ax = plt.subplots(2, n_curves + 1, figsize=(8 * (n_curves + 1), 8))
    elif plot_1d_curves:
        fig, ax = plt.subplots(3, 3, figsize=(32, 30))
        ax = ax.ravel()
    else:
        if resids:  # add derivatives plot
            fig, ax = plt.subplots(1, 4, figsize=(16, 4))
        else:
            fig, ax = plt.subplots(1, 3, figsize=(12, 4))

    linestyles = ['solid', 'dashed', 'dashdot', 'dotted'] * 3
    linewidth = 2
    alphas = [alpha] * 10
    colors = ['crimson', 'blue', 'skyblue', 'limegreen',
              'aquamarine', 'violet', 'black', 'brown', 'pink', 'gold']

    # Losses
    for i, (k, v) in enumerate(loss_dict1.items()):
        if plot_sep_curves:
            ax[0][0].plot(np.arange(len(v)), v, label=k,
                          alpha=alphas[i], linewidth=linewidth, color=colors[i],
                          linestyle=linestyles[i])
        else:
            ax[0].plot(np.arange(len(v)), v, label=k,
                       alpha=alphas[i], linewidth=linewidth, color=colors[i],
                       linestyle=linestyles[i])

    for i, (k, v) in enumerate(loss_dict2.items()):
        if plot_sep_curves:
            ax[1][0].plot(np.arange(len(v)), v, label=k,
                          alpha=alphas[i], linewidth=linewidth, color=colors[i],
                          linestyle=linestyles[i])
        else:
            ax[1].plot(np.arange(len(v)), v, label=k,
                       alpha=alphas[i], linewidth=linewidth, color=colors[i],
                       linestyle=linestyles[i])

    if plot_sep_curves:
        if len(loss_dict1.keys()) > 1:  # only add legend if > 1 curves
            ax[0][0].legend(loc='upper right')
        ax[0][0].set_xlabel('Iteration')
        ax[0][0].set_ylabel('Loss')
        if logloss:
            ax[0][0].set_yscale('log')
    else:
        if len(loss_dict1.keys()) > 1:  # only add legend if > 1 curves
            ax[0].legend(loc='upper right')
        ax[0].set_xlabel('Iteration')
        ax[0].set_ylabel('Loss')
        if logloss:
            ax[0].set_yscale('log')

    if plot_sep_curves:
        if len(loss_dict2.keys()) > 1:  # only add legend if > 1 curves
            ax[1][0].legend(loc='upper right')
        ax[1][0].set_xlabel('Iteration')
        ax[1][0].set_ylabel('Loss')
        if logloss:
            ax[1][0].set_yscale('log')
    else:
        if len(loss_dict2.keys()) > 1:  # only add legend if > 1 curves
            ax[1].legend(loc='upper right')
        ax[1].set_xlabel('Iteration')
        ax[1].set_ylabel('Loss')
        if logloss:
            ax[1].set_yscale('log')

    # Predictions
    if grid.shape[1] == 2:  # PDE
        x, y = grid[:, 0], grid[:, 1]
        xdim, ydim = dims.values()
        xx, yy = x.reshape((xdim, ydim)), y.reshape((xdim, ydim))
        for i, (k, v) in enumerate(pred_dict1.items()):
            v = v.reshape((xdim, ydim))
            cf = ax[2].contourf(xx.cpu().numpy(), yy.cpu().numpy(), v.cpu().numpy(), 10, cmap='RdYlBu')
            cb = fig.colorbar(cf, ax=ax[2])
            break
        xlab, ylab = dims.keys()
        ax[2].set_xlabel(f'${xlab}$')
        ax[2].set_ylabel(f'${ylab}$')
        ax[2].set_title('GAN-PINN')
    else:  # ODE
        if plot_sep_curves:
            for i, (k, v) in enumerate(pred_dict1.items()):
                if i % 2 == 0:
                    plot_id = int((i / 2) + 1)
                    style_id = 0
                else:
                    style_id = 1
                ax[0][plot_id].plot(grid, v, label=k,
                                    alpha=alphas[style_id], linestyle=linestyles[style_id],
                                    linewidth=linewidth, color=colors[style_id])
                ax[0][plot_id].set_xlabel('$t$')
                ax[0][plot_id].set_ylabel(k)
                ax[0][plot_id].legend()
        else:
            for i, (k, v) in enumerate(pred_dict1.items()):
                ax[2].plot(grid, v, label=k,
                           alpha=alphas[i], linestyle=linestyles[i],
                           linewidth=linewidth, color=colors[i])
            ax[2].set_xlabel('$t$')
            ax[2].set_ylabel('$x$')
            if len(pred_dict1.keys()) > 1:
                ax[2].legend(loc='upper right')

    # 1-dimensional curves for PDE 在 plot_results 函数中，有一个选项 plot_1d_curves
    # 专门用于绘制偏微分方程（PDE）的一维曲线。这些曲线通过在不同时间点提取数据来显示 PDE 解决
    # 方案在特定时间点随空间变量变化的情况。
    # 画出C-N格式的解：
    if grid.shape[1] == 2:  # PDE
        L = 1  # 空间范围
        T = 1  # 时间范围
        pi = torch.tensor(torch.pi)
        T = torch.tensor(T)
        Nx = 128  # 空间步数
        Nt = 128  # 时间步数
        dx = L / (Nx - 1)
        dt = T / (Nt - 1)
        # 生成 x 和 t 的网格节点
        x_values = torch.linspace(0, L, Nx).reshape(-1, 1)
        t_values_f = torch.linspace(0, T, Nt).reshape(-1, 1)
        t_values = T * torch.ones_like(x_values).reshape(-1, 1)
        plot_grid = torch.cat((x_values, t_values), 1)
        # 创建网格
        f_damp = G2(t_values_f)
        a = np.linspace(0, L, Nx)

        # real_solu = 2*torch.sin(2*pi*t_values_f)/(t_values_f + 1)
        real_solu = t_values_f + 1
        # real_solu = (t_values_f + 1)**2

        ax[5].plot(a, f_damp.detach().cpu().numpy(), label="$\hat{u}$",
                   alpha=alphas[0], linewidth=linewidth, color=colors[1],
                   linestyle=linestyles[0])
        ax[5].plot(a, real_solu.cpu(), label="$u$",
                   alpha=alphas[0], linewidth=linewidth, color=colors[0],
                   linestyle=linestyles[1])
        ax[5].set_xlabel('x')
        ax[5].set_ylabel('u(x,0)')
        ax[5].set_title('Optimal control(Initial condition)')
        ax[5].legend(loc='upper right')

        diff_squared_error = torch.square(f_damp - real_solu)
        diff_squared = torch.square(real_solu)
        relative_l2_error = torch.sqrt(torch.sum(diff_squared_error))
        relative_l2 = torch.sqrt(torch.sum(diff_squared))
        relative = relative_l2_error / relative_l2
        print('Control Relative L2 error: ', relative)

        ax[6].plot(a, np.abs((real_solu - f_damp).detach().cpu().numpy()), label="$|\hat{u}-u|$",
                   alpha=alphas[0], linewidth=linewidth, color=colors[0],
                   linestyle=linestyles[1])
        ax[6].set_xlabel('x')
        ax[6].set_ylabel("$|\hat{u}-u|$")
        ax[6].set_title('State at top wall')
        ax[6].legend(loc='upper right')

        real_solu_final = (x_values + 1) / 2 + 4 / 3
        # real_solu_final = (x_values+1)/2-1/(2*pi)
        # real_solu_final = (x_values + 1) / 2 + 2

        x_min_val = lambda t: 1 / (t + 1) + 1 / 3 * (t + 1) ** 2
        x_max_val = lambda t: 2 / (t + 1) + 1 / 3 * (t + 1) ** 2
        t_min_val = lambda x: x + 4 / 3

        # x_min_val = lambda t: 1 / (t + 1) - torch.cos(2 * pi * t) / (t + 1) / pi
        # x_max_val = lambda t: 2 / (t + 1) - torch.cos(2 * pi * t) / (t + 1) / pi
        # t_min_val = lambda x: x + 1 - 1 / pi

        # x_min_val = lambda t: 1 / (t + 1) + 1 / 4 * (t + 1) ** 3
        # x_max_val = lambda t: 2 / (t + 1) + 1 / 4 * (t + 1) ** 3
        # t_min_val = lambda x: x + 1 + 1/4

        xmin = 0
        xmax = 1
        Axy = (1 - x_values) * x_min_val(t_values) + x_values * x_max_val(t_values) + \
              (1 - t_values) * (t_min_val(x_values) - ((1 - x_values) * t_min_val(xmin * torch.ones_like(x_values))
                                                       + x_values * t_min_val(xmax * torch.ones_like(x_values))))
        f_final_u = Axy + x_values * (1 - x_values) * (1 - torch.exp(- t_values / T)) * G1(plot_grid)

        ax[7].plot(a, real_solu_final.cpu().numpy(), label="$u$",
                   alpha=alphas[0], linewidth=linewidth, color=colors[0],
                   linestyle=linestyles[1])
        ax[7].set_xlabel('x')
        ax[7].set_ylabel('u(x,1)')
        ax[7].set_title('Final state')
        ax[7].legend(loc='upper right')
        # print(f_final.shpae)
        # print(real_solu_final.shape)
        a = torch.linspace(0, L, Nx)
        # print(real_solu_final.detach().numpy())
        # print(f_final.detach().numpy())
        # print(real_solu_final.detach() - f_final.detach())
        ax[8].plot(a.cpu(), f_final_u.detach().cpu().numpy(), label="$|\hat{u}-u|$",
                   alpha=alphas[0], linewidth=linewidth, color=colors[0],
                   linestyle=linestyles[1])
        ax[8].set_xlabel('x')
        ax[8].set_ylabel("$|\hat{u}-u|$")
        ax[8].set_title('Final state')
        ax[8].legend(loc='upper right')
        ###########################################################
        # 创建空间和时间网格
        # 绘制图形

    # Derivatives
    if resids:
        for i, (k, v) in enumerate(resids.items()):
            if plot_sep_curves:
                ax[0][3].plot(np.arange(len(v)), v, label=k,
                              alpha=alphas[i], linewidth=linewidth, color=colors[i],
                              linestyle=linestyles[i])
                ax[0][3].set_yscale('log')
                ax[0][3].set_xlabel('Iteration')
                ax[0][3].set_ylabel('Residual')
                ax[0][3].legend(loc='upper right')

            else:
                if isinstance(v, list):
                    v = torch.tensor(v)
                ax[3].plot(np.arange(len(v)), v.cpu(), label=k,
                           alpha=alphas[i], linewidth=linewidth, color=colors[i],
                           linestyle=linestyles[i])
                ax[3].set_yscale('log')
                ax[3].set_xlabel('Iteration')
                ax[3].set_ylabel('Residual')
                ax[3].legend(loc='upper right')

    if cost_objective:
        for i, (k, v) in enumerate(cost_objective.items()):
            if plot_sep_curves:
                ax[0][4].plot(np.arange(len(v)), v, label=k,
                              alpha=alphas[i], linewidth=linewidth, color=colors[i],
                              linestyle=linestyles[i])
                ax[0][4].set_yscale('log')
                ax[0][4].set_xlabel('Iteration')
                ax[0][4].set_ylabel('Cost_objective')
                ax[0][4].legend(loc='upper right')

            else:
                if isinstance(v, list):
                    v = torch.tensor(v)
                ax[4].plot(np.arange(len(v)), v.cpu(), label=k,
                           alpha=alphas[i], linewidth=linewidth, color=colors[i],
                           linestyle=linestyles[i])
                ax[4].set_yscale('log')
                ax[4].set_xlabel('Iteration')
                ax[4].set_ylabel('Cost_objective')
                ax[4].legend(loc='upper right')

    if save:
        print(f'Saving results to {dirname}')
        if not os.path.exists(dirname):
            os.mkdir(dirname)
        plt.savefig(os.path.join(dirname, f'gan_plot_final_GPU_{lambdas}.png'), bbox_inches='tight', dpi=300)
        for k, v in loss_dict1.items():
            np.save(os.path.join(dirname, f"{k}_loss_GPU_{lambdas}"), v)
        for k, v in loss_dict2.items():
            np.save(os.path.join(dirname, f"{k}_loss_GPU_{lambdas}"), v)
        for k, v in cost_result.items():
            np.save(os.path.join(dirname, f"{k}_loss_GPU_{lambdas}"), v)
    else:
        plt.show()

def plot_results_L2(wj,G1,G2, loss_dict, pred_dict, grid, diff_dict=None,residuals = None, cost_objective=None, clear=False,
    save=False, dirname=None, logloss=False, alpha=0.8,plot_sep_curves=False, dims=None,plot_1d_curves=True):

    plt.rc('axes', titlesize=20, labelsize=20)
    plt.rc('legend', fontsize=16)
    plt.rc('xtick', labelsize=18)
    plt.rc('ytick', labelsize=18)
    # plt.rcParams['text.usetex'] = True

    if clear:
      clear_output(True)

    if save and not dirname:
        raise RuntimeError('Please provide a directory name `dirname` when `save=True`.')

    fig, ax = plt.subplots(3, 3, figsize=(32, 32))
    ax = ax.ravel()
    #print(ax)

    linestyles = ['solid', 'dashed', 'dashdot', 'dotted']*3
    linewidth = 2
    alphas = [alpha]*10
    colors = ['crimson', 'blue', 'skyblue', 'limegreen',
        'aquamarine', 'violet', 'black', 'brown', 'pink', 'gold']

    # Predictions
    if grid.shape[1] == 2: # PDE
        x, y = grid[:, 0], grid[:, 1]
        xdim, ydim = dims.values()
        xx, yy = x.reshape((xdim, ydim)), y.reshape((xdim, ydim))
        for i, (k, v) in enumerate(pred_dict.items()):
            v = v.reshape((xdim, ydim))
            cf = ax[3].contourf(xx.cpu(), yy.cpu(), v.cpu(), cmap='Reds')
            cb = fig.colorbar(cf, format='%.0e', ax=ax[3])
            break
        xlab, ylab = dims.keys()
        ax[3].set_xlabel(f'${xlab}$')
        ax[3].set_ylabel(f'${ylab}$')
        ax[3].set_title('PINN')
    else: # ODE
        if plot_sep_curves:
            for i, (k, v) in enumerate(pred_dict.items()):
                if i%2 == 0:
                    plot_id = int((i/2)+1)
                    style_id = 0
                else:
                    style_id = 1
                ax[2][plot_id].plot(grid, v, label=k,
                alpha=alphas[style_id], linestyle=linestyles[style_id],
                linewidth=linewidth, color=colors[style_id])
                ax[2][plot_id].set_xlabel('$t$')
                ax[2][plot_id].set_ylabel(k)
                ax[2][plot_id].legend()
        else:
            for i, (k, v) in enumerate(pred_dict.items()):
                ax[2].plot(grid, v, label=k,
                    alpha=alphas[i], linestyle=linestyles[i],
                    linewidth=linewidth, color=colors[i])
            ax[2].set_xlabel('$t$')
            ax[2].set_ylabel('$x$')
            if len(pred_dict.keys()) > 1:
                ax[2].legend(loc='upper right')


    # 1-dimensional curves for PDE 在 plot_results 函数中，有一个选项 plot_1d_curves
    # 专门用于绘制偏微分方程（PDE）的一维曲线。这些曲线通过在不同时间点提取数据来显示 PDE 解决
    # 方案在特定时间点随空间变量变化的情况。
    #画出C-N格式的解：
    L = 1  # 空间范围
    T = 1  # 时间范围
    T = torch.tensor(T)
    Nx = 128  # 空间步数
    Nt = 128  # 时间步数
    pi = torch.tensor(torch.pi)
    # 生成 x 和 t 的网格节点
    x_values = torch.linspace(0, L, Nx).reshape(-1, 1)
    t_values = T*torch.ones_like(x_values).reshape(-1, 1)
    t_values_final = torch.linspace(0, T, Nt).reshape(-1, 1)
    plot_grid = torch.cat((x_values, t_values), 1)
    # 创建网格
    #x_grid, t_grid = torch.meshgrid(x_values, t_values)
    #X_star = torch.hstack((x_grid.flatten()[:, None], t_grid.flatten()[:, None]))
    f_damp = G2(t_values_final)
    a = np.linspace(0, 1, Nx)

    #real_solu = (t_values_final + 1)**2
    real_solu = t_values_final + 1
    #real_solu = 2 * torch.sin(2 * pi * t_values_final) / (t_values_final + 1)

    ax[4].plot(a, f_damp.detach().cpu(), label="$\hat{u}$",
               alpha=alphas[0], linewidth=linewidth, color=colors[1],
               linestyle=linestyles[0])
    ax[4].plot(a, real_solu.detach().cpu(), label="$u$",
               alpha=alphas[0], linewidth=linewidth, color=colors[0],
               linestyle=linestyles[1])
    ax[4].set_xlabel('t')
    ax[4].set_ylabel('v')
    ax[4].set_title('Optimal control function')
    ax[4].legend(loc='upper right')

    diff_squared_error = torch.square(f_damp - real_solu)
    diff_squared = torch.square(real_solu)
    relative_l2_error = torch.sqrt(torch.sum(diff_squared_error))
    relative_l2 = torch.sqrt(torch.sum(diff_squared))
    relative = relative_l2_error / relative_l2
    print('Relative L2 error: ', relative)

    ax[5].plot(a, np.abs((real_solu - f_damp).detach().cpu().numpy()), label="$|\hat{u}-u|$",
               alpha=alphas[0], linewidth=linewidth, color=colors[0],
               linestyle=linestyles[1])
    ax[5].set_xlabel('x')
    ax[5].set_ylabel("$|\hat{u}-u|$")
    ax[5].set_title('Optimal control function error')
    ax[5].legend(loc='upper right')
    xmin = 0
    xmax = 1
    x_min_val = lambda t: 1 / (t + 1) + 1 / 3 * (t + 1) ** 2
    x_max_val = lambda t: 2 / (t + 1) + 1 / 3 * (t + 1) ** 2
    t_min_val = lambda x: x + 4 / 3
    real_solu_final = (x_values + 1) / 2 +4/3
    #x_min_val = lambda t: 1 / (t + 1) - torch.cos(2 * pi * t) / (t + 1) / pi
    #x_max_val = lambda t: 2 / (t + 1) - torch.cos(2 * pi * t) / (t + 1) / pi
    #t_min_val = lambda x: x + 1 - 1 / pi
    #real_solu_final = (x_values + 1) / 2 + 2
    #x_min_val = lambda t: 1 / (t + 1) + 1 / 4 * (t + 1) ** 3
    #x_max_val = lambda t: 2 / (t + 1) + 1 / 4 * (t + 1) ** 3
    #t_min_val = lambda x: x + 1 + 1 / 4

    Axy = (1 - x_values) * x_min_val(t_values) + x_values * x_max_val(t_values) + \
          (1 - t_values) * (t_min_val(x_values) - ((1 - x_values) * t_min_val(xmin * torch.ones_like(x_values))
                                                   + x_values * t_min_val(xmax * torch.ones_like(x_values))))

    if len(residuals.items()) == 3:
        f_final = G1(plot_grid)
        print('soft constrain')
    else:
        f_final =  Axy + x_values * (1 - x_values) * (1 - torch.exp(- t_values / T)) * G1(plot_grid)
        print('hard constrain')

    diff_squared_error_final = torch.square(f_final - real_solu_final)
    diff_squared_final = torch.square(real_solu_final)
    relative_l2_error_final = torch.sqrt(torch.sum(diff_squared_error_final))
    relative_l2_final = torch.sqrt(torch.sum(diff_squared_final))
    relative_final_final = relative_l2_error_final / relative_l2_final
    print('Final state Relative L2 error: ', relative_final_final)

    ax[6].plot(a, f_final.detach().cpu(), label="$\hat{u}$",
               alpha=alphas[0], linewidth=linewidth, color=colors[1],
               linestyle=linestyles[0])
    ax[6].plot(a, real_solu_final.cpu(), label="$u$",
               alpha=alphas[0], linewidth=linewidth, color=colors[0],
               linestyle=linestyles[1])
    ax[6].set_xlabel('x')
    ax[6].set_ylabel('u(x,5)')
    ax[6].set_title('Final state')
    ax[6].legend(loc='upper right')

    ax[7].plot(a, np.abs((real_solu_final - f_final).detach().cpu().numpy()), label="$|\hat{u}-u|$",
               alpha=alphas[0], linewidth=linewidth, color=colors[0],
               linestyle=linestyles[1])
    ax[7].set_xlabel('x')
    ax[7].set_ylabel("$|\hat{u}-u|$")
    ax[7].set_title('Final state')
    ax[7].legend(loc='upper right')

    if residuals:
        for i, (k, v) in enumerate(residuals.items()):
            if plot_sep_curves:
                ax[0][0].plot(np.arange(len(v)), v, label=k,
                              alpha=alphas[i], linewidth=linewidth, color=colors[i],
                              linestyle=linestyles[i])
                ax[0][0].set_yscale('log')
                ax[0][0].set_xlabel('Iteration')
                ax[0][0].set_ylabel('Residual/Bound/Initial')
                ax[0][0].legend(loc='upper right')

            else:
                if isinstance(v, list):
                    v = torch.tensor(v)  # Convert list to tensor
                ax[1].plot(np.arange(len(v)), v.cpu(), label=k,
                           alpha=alphas[i], linewidth=linewidth, color=colors[i],
                           linestyle=linestyles[i])
                ax[1].set_yscale('log')
                ax[1].set_xlabel('Iteration')
                ax[1].set_ylabel('Residual/Bound/Initial')
                ax[1].legend(loc='upper right')


    if cost_objective:
        for i, (k, v) in enumerate(cost_objective.items()):
            if plot_sep_curves:
                ax[0][1].plot(np.arange(len(v)), v, label=k,
                              alpha=alphas[i], linewidth=linewidth, color=colors[i],
                              linestyle=linestyles[i])
                ax[0][1].set_yscale('log')
                ax[0][1].set_xlabel('Iteration')
                ax[0][1].set_ylabel('Cost_objective')
                ax[0][1].legend(loc='upper right')

            else:
                if isinstance(v, list):
                    v = torch.tensor(v)  # Convert list to tensor
                ax[2].plot(np.arange(len(v)), v.cpu(), label=k,
                           alpha=alphas[i], linewidth=linewidth, color=colors[i],
                           linestyle=linestyles[i])
                ax[2].set_yscale('log')
                ax[2].set_xlabel('Iteration')
                ax[2].set_ylabel('Cost_objective')
                ax[2].legend(loc='upper right')

    if save:
        print(f'Saving results to {dirname}')
        if not os.path.exists(dirname):
            os.mkdir(dirname)
        if len(residuals.items()) == 3:
            plt.savefig(os.path.join(dirname, f'soft_plot_{wj}.png'), bbox_inches='tight', dpi=300)
        else:
            plt.savefig(os.path.join(dirname, f'hard_plot_{wj}.png'), bbox_inches='tight', dpi=300)
        for k, v in loss_dict.items():
            np.save(os.path.join(dirname, f"{k}_loss"), v)

    else:
        plt.show()

def plot_results_L2_fs(cost_result,wj,G1,G2, loss_dict, pred_dict, grid, diff_dict=None,residuals = None, cost_objective=None, clear=False,
    save=False, dirname=None, logloss=False, alpha=0.8,plot_sep_curves=False, dims=None,plot_1d_curves=True):

    plt.rc('axes', titlesize=20, labelsize=20)
    plt.rc('legend', fontsize=16)
    plt.rc('xtick', labelsize=18)
    plt.rc('ytick', labelsize=18)
    # plt.rcParams['text.usetex'] = True

    if clear:
      clear_output(True)

    if save and not dirname:
        raise RuntimeError('Please provide a directory name `dirname` when `save=True`.')

    fig, ax = plt.subplots(3, 3, figsize=(32, 32))
    ax = ax.ravel()
    #print(ax)

    linestyles = ['solid', 'dashed', 'dashdot', 'dotted']*3
    linewidth = 2
    alphas = [alpha]*10
    colors = ['crimson', 'blue', 'skyblue', 'limegreen',
        'aquamarine', 'violet', 'black', 'brown', 'pink', 'gold']

    # Predictions
    if grid.shape[1] == 2: # PDE
        x, y = grid[:, 0], grid[:, 1]
        xdim, ydim = dims.values()
        xx, yy = x.reshape((xdim, ydim)), y.reshape((xdim, ydim))
        for i, (k, v) in enumerate(pred_dict.items()):
            v = v.reshape((xdim, ydim))
            cf = ax[3].contourf(xx.cpu(), yy.cpu(), v.cpu(), cmap='Reds')
            cb = fig.colorbar(cf, format='%.0e', ax=ax[3])
            break
        xlab, ylab = dims.keys()
        ax[3].set_xlabel(f'${xlab}$')
        ax[3].set_ylabel(f'${ylab}$')
        ax[3].set_title('PINN')
    else: # ODE
        if plot_sep_curves:
            for i, (k, v) in enumerate(pred_dict.items()):
                if i%2 == 0:
                    plot_id = int((i/2)+1)
                    style_id = 0
                else:
                    style_id = 1
                ax[2][plot_id].plot(grid, v, label=k,
                alpha=alphas[style_id], linestyle=linestyles[style_id],
                linewidth=linewidth, color=colors[style_id])
                ax[2][plot_id].set_xlabel('$t$')
                ax[2][plot_id].set_ylabel(k)
                ax[2][plot_id].legend()
        else:
            for i, (k, v) in enumerate(pred_dict.items()):
                ax[2].plot(grid, v, label=k,
                    alpha=alphas[i], linestyle=linestyles[i],
                    linewidth=linewidth, color=colors[i])
            ax[2].set_xlabel('$t$')
            ax[2].set_ylabel('$x$')
            if len(pred_dict.keys()) > 1:
                ax[2].legend(loc='upper right')


    # 1-dimensional curves for PDE 在 plot_results 函数中，有一个选项 plot_1d_curves
    # 专门用于绘制偏微分方程（PDE）的一维曲线。这些曲线通过在不同时间点提取数据来显示 PDE 解决
    # 方案在特定时间点随空间变量变化的情况。
    #画出C-N格式的解：
    L = 1  # 空间范围
    T = 1  # 时间范围
    T = torch.tensor(T)
    Nx = 128  # 空间步数
    Nt = 128  # 时间步数
    pi = torch.tensor(torch.pi)
    # 生成 x 和 t 的网格节点
    x_values = torch.linspace(0, L, Nx).reshape(-1, 1)
    t_values = T*torch.ones_like(x_values).reshape(-1, 1)
    t_values_final = torch.linspace(0, T, Nt).reshape(-1, 1)
    plot_grid = torch.cat((x_values, t_values), 1)
    # 创建网格
    #x_grid, t_grid = torch.meshgrid(x_values, t_values)
    #X_star = torch.hstack((x_grid.flatten()[:, None], t_grid.flatten()[:, None]))
    f_damp = G2(t_values_final)
    a = np.linspace(0, 1, Nx)

    #real_solu = (t_values_final + 1)**2
    real_solu = t_values_final + 1
    #real_solu = 2 * torch.sin(2 * pi * t_values_final) / (t_values_final + 1)

    ax[4].plot(a, f_damp.detach().cpu(), label="$\hat{u}$",
               alpha=alphas[0], linewidth=linewidth, color=colors[1],
               linestyle=linestyles[0])
    ax[4].plot(a, real_solu.detach().cpu(), label="$u$",
               alpha=alphas[0], linewidth=linewidth, color=colors[0],
               linestyle=linestyles[1])
    ax[4].set_xlabel('t')
    ax[4].set_ylabel('v')
    ax[4].set_title('Optimal control function')
    ax[4].legend(loc='upper right')

    diff_squared_error = torch.square(f_damp - real_solu)
    diff_squared = torch.square(real_solu)
    relative_l2_error = torch.sqrt(torch.sum(diff_squared_error))
    relative_l2 = torch.sqrt(torch.sum(diff_squared))
    relative = relative_l2_error / relative_l2
    print('Relative L2 error: ', relative)

    ax[5].plot(a, np.abs((real_solu - f_damp).detach().cpu().numpy()), label="$|\hat{u}-u|$",
               alpha=alphas[0], linewidth=linewidth, color=colors[0],
               linestyle=linestyles[1])
    ax[5].set_xlabel('x')
    ax[5].set_ylabel("$|\hat{u}-u|$")
    ax[5].set_title('Optimal control function error')
    ax[5].legend(loc='upper right')
    xmin = 0
    xmax = 1
    x_min_val = lambda t: 1 / (t + 1) + 1 / 3 * (t + 1) ** 2
    x_max_val = lambda t: 2 / (t + 1) + 1 / 3 * (t + 1) ** 2
    t_min_val = lambda x: x + 4 / 3
    real_solu_final = (x_values + 1) / 2 +4/3
    #x_min_val = lambda t: 1 / (t + 1) - torch.cos(2 * pi * t) / (t + 1) / pi
    #x_max_val = lambda t: 2 / (t + 1) - torch.cos(2 * pi * t) / (t + 1) / pi
    #t_min_val = lambda x: x + 1 - 1 / pi
    #real_solu_final = (x_values + 1) / 2 + 2
    #x_min_val = lambda t: 1 / (t + 1) + 1 / 4 * (t + 1) ** 3
    #x_max_val = lambda t: 2 / (t + 1) + 1 / 4 * (t + 1) ** 3
    #t_min_val = lambda x: x + 1 + 1 / 4

    Axy = (1 - x_values) * x_min_val(t_values) + x_values * x_max_val(t_values) + \
          (1 - t_values) * (t_min_val(x_values) - ((1 - x_values) * t_min_val(xmin * torch.ones_like(x_values))
                                                   + x_values * t_min_val(xmax * torch.ones_like(x_values))))

    if len(residuals.items()) == 3:
        f_final = G1(plot_grid)
        print('soft constrain')
    else:
        f_final =  Axy + x_values * (1 - x_values) * (1 - torch.exp(- t_values / T)) * G1(plot_grid)
        print('hard constrain')

    diff_squared_error_final = torch.square(f_final - real_solu_final)
    diff_squared_final = torch.square(real_solu_final)
    relative_l2_error_final = torch.sqrt(torch.sum(diff_squared_error_final))
    relative_l2_final = torch.sqrt(torch.sum(diff_squared_final))
    relative_final_final = relative_l2_error_final / relative_l2_final
    print('Final state Relative L2 error: ', relative_final_final)

    ax[6].plot(a, f_final.detach().cpu(), label="$\hat{u}$",
               alpha=alphas[0], linewidth=linewidth, color=colors[1],
               linestyle=linestyles[0])
    ax[6].plot(a, real_solu_final.cpu(), label="$u$",
               alpha=alphas[0], linewidth=linewidth, color=colors[0],
               linestyle=linestyles[1])
    ax[6].set_xlabel('x')
    ax[6].set_ylabel('u(x,5)')
    ax[6].set_title('Final state')
    ax[6].legend(loc='upper right')

    ax[7].plot(a, np.abs((real_solu_final - f_final).detach().cpu().numpy()), label="$|\hat{u}-u|$",
               alpha=alphas[0], linewidth=linewidth, color=colors[0],
               linestyle=linestyles[1])
    ax[7].set_xlabel('x')
    ax[7].set_ylabel("$|\hat{u}-u|$")
    ax[7].set_title('Final state')
    ax[7].legend(loc='upper right')

    if residuals:
        for i, (k, v) in enumerate(residuals.items()):
            if plot_sep_curves:
                ax[0][0].plot(np.arange(len(v)), v, label=k,
                              alpha=alphas[i], linewidth=linewidth, color=colors[i],
                              linestyle=linestyles[i])
                ax[0][0].set_yscale('log')
                ax[0][0].set_xlabel('Iteration')
                ax[0][0].set_ylabel('Residual/Bound/Initial')
                ax[0][0].legend(loc='upper right')

            else:
                if isinstance(v, list):
                    v = torch.tensor(v)  # Convert list to tensor
                ax[1].plot(np.arange(len(v)), v.cpu(), label=k,
                           alpha=alphas[i], linewidth=linewidth, color=colors[i],
                           linestyle=linestyles[i])
                ax[1].set_yscale('log')
                ax[1].set_xlabel('Iteration')
                ax[1].set_ylabel('Residual/Bound/Initial')
                ax[1].legend(loc='upper right')


    if cost_objective:
        for i, (k, v) in enumerate(cost_objective.items()):
            if plot_sep_curves:
                ax[0][1].plot(np.arange(len(v)), v, label=k,
                              alpha=alphas[i], linewidth=linewidth, color=colors[i],
                              linestyle=linestyles[i])
                ax[0][1].set_yscale('log')
                ax[0][1].set_xlabel('Iteration')
                ax[0][1].set_ylabel('Cost_objective')
                ax[0][1].legend(loc='upper right')

            else:
                if isinstance(v, list):
                    v = torch.tensor(v)  # Convert list to tensor
                ax[2].plot(np.arange(len(v)), v.cpu(), label=k,
                           alpha=alphas[i], linewidth=linewidth, color=colors[i],
                           linestyle=linestyles[i])
                ax[2].set_yscale('log')
                ax[2].set_xlabel('Iteration')
                ax[2].set_ylabel('Cost_objective')
                ax[2].legend(loc='upper right')

    if save:
        print(f'Saving results to {dirname}')
        if not os.path.exists(dirname):
            os.mkdir(dirname)
        if len(residuals.items()) == 3:
            plt.savefig(os.path.join(dirname, f'soft_plot_{wj}.png'), bbox_inches='tight', dpi=300)
        else:
            plt.savefig(os.path.join(dirname, f'hard_plot_{wj}.png'), bbox_inches='tight', dpi=300)
        for k, v in loss_dict.items():
            np.save(os.path.join(dirname, f"{k}_soft"), v)
        for k, v in cost_result.items():
            np.save(os.path.join(dirname, f"{k}_soft"), v)
    else:
        plt.show()

def plot_lulu_penalty(wj,G1,G2, loss_dict, pred_dict, grid, diff_dict=None,residuals = None, cost_objective=None, clear=False,
    save=False, dirname=None, logloss=False, alpha=0.8,plot_sep_curves=False, dims=None,plot_1d_curves=True):

    plt.rc('axes', titlesize=20, labelsize=20)
    plt.rc('legend', fontsize=16)
    plt.rc('xtick', labelsize=18)
    plt.rc('ytick', labelsize=18)
    # plt.rcParams['text.usetex'] = True

    if clear:
      clear_output(True)

    if save and not dirname:
        raise RuntimeError('Please provide a directory name `dirname` when `save=True`.')

    fig, ax = plt.subplots(3, 3, figsize=(32, 32))
    ax = ax.ravel()
    #print(ax)

    linestyles = ['solid', 'dashed', 'dashdot', 'dotted']*3
    linewidth = 2
    alphas = [alpha]*10
    colors = ['crimson', 'blue', 'skyblue', 'limegreen',
        'aquamarine', 'violet', 'black', 'brown', 'pink', 'gold']

    # Predictions
    if grid.shape[1] == 2: # PDE
        x, y = grid[:, 0], grid[:, 1]
        xdim, ydim = dims.values()
        xx, yy = x.reshape((xdim, ydim)), y.reshape((xdim, ydim))
        for i, (k, v) in enumerate(pred_dict.items()):
            v = v.reshape((xdim, ydim))
            cf = ax[3].contourf(xx.cpu(), yy.cpu(), v.cpu(), cmap='Reds')
            cb = fig.colorbar(cf, format='%.0e', ax=ax[3])
            break
        xlab, ylab = dims.keys()
        ax[3].set_xlabel(f'${xlab}$')
        ax[3].set_ylabel(f'${ylab}$')
        ax[3].set_title('PINN')
    else: # ODE
        if plot_sep_curves:
            for i, (k, v) in enumerate(pred_dict.items()):
                if i%2 == 0:
                    plot_id = int((i/2)+1)
                    style_id = 0
                else:
                    style_id = 1
                ax[2][plot_id].plot(grid, v, label=k,
                alpha=alphas[style_id], linestyle=linestyles[style_id],
                linewidth=linewidth, color=colors[style_id])
                ax[2][plot_id].set_xlabel('$t$')
                ax[2][plot_id].set_ylabel(k)
                ax[2][plot_id].legend()
        else:
            for i, (k, v) in enumerate(pred_dict.items()):
                ax[2].plot(grid, v, label=k,
                    alpha=alphas[i], linestyle=linestyles[i],
                    linewidth=linewidth, color=colors[i])
            ax[2].set_xlabel('$t$')
            ax[2].set_ylabel('$x$')
            if len(pred_dict.keys()) > 1:
                ax[2].legend(loc='upper right')


    # 1-dimensional curves for PDE 在 plot_results 函数中，有一个选项 plot_1d_curves
    # 专门用于绘制偏微分方程（PDE）的一维曲线。这些曲线通过在不同时间点提取数据来显示 PDE 解决
    # 方案在特定时间点随空间变量变化的情况。
    #画出C-N格式的解：
    L = 1  # 空间范围
    T = 1  # 时间范围
    T = torch.tensor(T)
    Nx = 128  # 空间步数
    Nt = 128  # 时间步数
    pi = torch.tensor(torch.pi)
    # 生成 x 和 t 的网格节点
    x_values = torch.linspace(0, L, Nx).reshape(-1, 1)
    t_values = T*torch.ones_like(x_values).reshape(-1, 1)
    t_values_final = torch.linspace(0, T, Nt).reshape(-1, 1)
    plot_grid = torch.cat((x_values, t_values), 1)
    # 创建网格
    #x_grid, t_grid = torch.meshgrid(x_values, t_values)
    #X_star = torch.hstack((x_grid.flatten()[:, None], t_grid.flatten()[:, None]))
    f_damp = G2(t_values_final)
    a = np.linspace(0, 1, Nx)

    #real_solu = (t_values_final + 1)**2
    real_solu = t_values_final + 1
    #real_solu = 2 * torch.sin(2 * pi * t_values_final) / (t_values_final + 1)

    ax[4].plot(a, f_damp.detach().cpu(), label="$\hat{u}$",
               alpha=alphas[0], linewidth=linewidth, color=colors[1],
               linestyle=linestyles[0])
    ax[4].plot(a, real_solu.detach(), label="$u$",
               alpha=alphas[0], linewidth=linewidth, color=colors[0],
               linestyle=linestyles[1])
    ax[4].set_xlabel('t')
    ax[4].set_ylabel('v')
    ax[4].set_title('Optimal control function')
    ax[4].legend(loc='upper right')

    diff_squared_error = torch.square(f_damp - real_solu)
    diff_squared = torch.square(real_solu)
    relative_l2_error = torch.sqrt(torch.sum(diff_squared_error))
    relative_l2 = torch.sqrt(torch.sum(diff_squared))
    relative = relative_l2_error / relative_l2
    print('Relative L2 error: ', relative)

    ax[5].plot(a, np.abs((real_solu - f_damp).detach().cpu().numpy()), label="$|\hat{u}-u|$",
               alpha=alphas[0], linewidth=linewidth, color=colors[0],
               linestyle=linestyles[1])
    ax[5].set_xlabel('x')
    ax[5].set_ylabel("$|\hat{u}-u|$")
    ax[5].set_title('Optimal control function error')
    ax[5].legend(loc='upper right')
    xmin = 0
    xmax = 1
    x_min_val = lambda t: 1 / (t + 1) + 1 / 3 * (t + 1) ** 2
    x_max_val = lambda t: 2 / (t + 1) + 1 / 3 * (t + 1) ** 2
    t_min_val = lambda x: x + 4 / 3
    real_solu_final = (x_values + 1) / 2 +4/3
    #x_min_val = lambda t: 1 / (t + 1) - torch.cos(2 * pi * t) / (t + 1) / pi
    #x_max_val = lambda t: 2 / (t + 1) - torch.cos(2 * pi * t) / (t + 1) / pi
    #t_min_val = lambda x: x + 1 - 1 / pi
    #real_solu_final = (x_values + 1) / 2 + 2
    #x_min_val = lambda t: 1 / (t + 1) + 1 / 4 * (t + 1) ** 3
    #x_max_val = lambda t: 2 / (t + 1) + 1 / 4 * (t + 1) ** 3
    #t_min_val = lambda x: x + 1 + 1 / 4

    Axy = (1 - x_values) * x_min_val(t_values) + x_values * x_max_val(t_values) + \
          (1 - t_values) * (t_min_val(x_values) - ((1 - x_values) * t_min_val(xmin * torch.ones_like(x_values))
                                                   + x_values * t_min_val(xmax * torch.ones_like(x_values))))

    if len(residuals.items()) == 3:
        f_final = G1(plot_grid)
        print('soft constrain')
    else:
        f_final =  Axy + x_values * (1 - x_values) * (1 - torch.exp(- t_values / T)) * G1(plot_grid)
        print('hard constrain')

    diff_squared_error_final = torch.square(f_final - real_solu_final)
    diff_squared_final = torch.square(real_solu_final)
    relative_l2_error_final = torch.sqrt(torch.sum(diff_squared_error_final))
    relative_l2_final = torch.sqrt(torch.sum(diff_squared_final))
    relative_final_final = relative_l2_error_final / relative_l2_final
    print('Final state Relative L2 error: ', relative_final_final)

    ax[6].plot(a, f_final.detach().cpu(), label="$\hat{u}$",
               alpha=alphas[0], linewidth=linewidth, color=colors[1],
               linestyle=linestyles[0])
    ax[6].plot(a, real_solu_final.cpu(), label="$u$",
               alpha=alphas[0], linewidth=linewidth, color=colors[0],
               linestyle=linestyles[1])
    ax[6].set_xlabel('x')
    ax[6].set_ylabel('u(x,5)')
    ax[6].set_title('Final state')
    ax[6].legend(loc='upper right')

    ax[7].plot(a, np.abs((real_solu_final - f_final).detach().cpu().numpy()), label="$|\hat{u}-u|$",
               alpha=alphas[0], linewidth=linewidth, color=colors[0],
               linestyle=linestyles[1])
    ax[7].set_xlabel('x')
    ax[7].set_ylabel("$|\hat{u}-u|$")
    ax[7].set_title('Final state')
    ax[7].legend(loc='upper right')

    if residuals:
        for i, (k, v) in enumerate(residuals.items()):
            if plot_sep_curves:
                ax[0][0].plot(np.arange(len(v)), v, label=k,
                              alpha=alphas[i], linewidth=linewidth, color=colors[i],
                              linestyle=linestyles[i])
                ax[0][0].set_yscale('log')
                ax[0][0].set_xlabel('Iteration')
                ax[0][0].set_ylabel('Residual/Bound/Initial')
                ax[0][0].legend(loc='upper right')

            else:
                ax[1].plot(np.arange(len(v)), v, label=k,
                           alpha=alphas[i], linewidth=linewidth, color=colors[i],
                           linestyle=linestyles[i])
                ax[1].set_yscale('log')
                ax[1].set_xlabel('Iteration')
                ax[1].set_ylabel('Residual/Bound/Initial')
                ax[1].legend(loc='upper right')


    if cost_objective:
        for i, (k, v) in enumerate(cost_objective.items()):
            if plot_sep_curves:
                ax[0][1].plot(np.arange(len(v)), v, label=k,
                              alpha=alphas[i], linewidth=linewidth, color=colors[i],
                              linestyle=linestyles[i])
                ax[0][1].set_yscale('log')
                ax[0][1].set_xlabel('Iteration')
                ax[0][1].set_ylabel('Cost_objective')
                ax[0][1].legend(loc='upper right')

            else:
                if isinstance(v, list):
                    v = torch.tensor(v)  # Convert list to tensor
                ax[2].plot(np.arange(len(v)), v.cpu(), label=k,
                           alpha=alphas[i], linewidth=linewidth, color=colors[i],
                           linestyle=linestyles[i])
                ax[2].set_yscale('log')
                ax[2].set_xlabel('Iteration')
                ax[2].set_ylabel('Cost_objective')
                ax[2].legend(loc='upper right')

    if save:
        print(f'Saving results to {dirname}')
        if not os.path.exists(dirname):
            os.mkdir(dirname)
        plt.savefig(os.path.join(dirname, f'lulu_penalty_plot_{wj}.png'), bbox_inches='tight', dpi=300)
        for k, v in loss_dict.items():
            np.save(os.path.join(dirname, f"{k}_lulu_penalty_loss"), v)

    else:
        plt.show()

def plot_lulu_augment(wj,G1,G2, loss_dict, pred_dict, grid, diff_dict=None,residuals = None, cost_objective=None, clear=False,
    save=False, dirname=None, logloss=False, alpha=0.8,plot_sep_curves=False, dims=None,plot_1d_curves=True):

    plt.rc('axes', titlesize=20, labelsize=20)
    plt.rc('legend', fontsize=16)
    plt.rc('xtick', labelsize=18)
    plt.rc('ytick', labelsize=18)
    # plt.rcParams['text.usetex'] = True

    if clear:
      clear_output(True)

    if save and not dirname:
        raise RuntimeError('Please provide a directory name `dirname` when `save=True`.')

    fig, ax = plt.subplots(3, 3, figsize=(32, 32))
    ax = ax.ravel()
    #print(ax)

    linestyles = ['solid', 'dashed', 'dashdot', 'dotted']*3
    linewidth = 2
    alphas = [alpha]*10
    colors = ['crimson', 'blue', 'skyblue', 'limegreen',
        'aquamarine', 'violet', 'black', 'brown', 'pink', 'gold']

    # Predictions
    if grid.shape[1] == 2: # PDE
        x, y = grid[:, 0], grid[:, 1]
        xdim, ydim = dims.values()
        xx, yy = x.reshape((xdim, ydim)), y.reshape((xdim, ydim))
        for i, (k, v) in enumerate(pred_dict.items()):
            v = v.reshape((xdim, ydim))
            cf = ax[3].contourf(xx.cpu(), yy.cpu(), v.cpu(), cmap='Reds')
            cb = fig.colorbar(cf, format='%.0e', ax=ax[3])
            break
        xlab, ylab = dims.keys()
        ax[3].set_xlabel(f'${xlab}$')
        ax[3].set_ylabel(f'${ylab}$')
        ax[3].set_title('PINN')
    else: # ODE
        if plot_sep_curves:
            for i, (k, v) in enumerate(pred_dict.items()):
                if i%2 == 0:
                    plot_id = int((i/2)+1)
                    style_id = 0
                else:
                    style_id = 1
                ax[2][plot_id].plot(grid, v, label=k,
                alpha=alphas[style_id], linestyle=linestyles[style_id],
                linewidth=linewidth, color=colors[style_id])
                ax[2][plot_id].set_xlabel('$t$')
                ax[2][plot_id].set_ylabel(k)
                ax[2][plot_id].legend()
        else:
            for i, (k, v) in enumerate(pred_dict.items()):
                ax[2].plot(grid, v, label=k,
                    alpha=alphas[i], linestyle=linestyles[i],
                    linewidth=linewidth, color=colors[i])
            ax[2].set_xlabel('$t$')
            ax[2].set_ylabel('$x$')
            if len(pred_dict.keys()) > 1:
                ax[2].legend(loc='upper right')


    # 1-dimensional curves for PDE 在 plot_results 函数中，有一个选项 plot_1d_curves
    # 专门用于绘制偏微分方程（PDE）的一维曲线。这些曲线通过在不同时间点提取数据来显示 PDE 解决
    # 方案在特定时间点随空间变量变化的情况。
    #画出C-N格式的解：
    L = 1  # 空间范围
    T = 1  # 时间范围
    T = torch.tensor(T)
    Nx = 128  # 空间步数
    Nt = 128  # 时间步数
    pi = torch.tensor(torch.pi)
    # 生成 x 和 t 的网格节点
    x_values = torch.linspace(0, L, Nx).reshape(-1, 1)
    t_values = T*torch.ones_like(x_values).reshape(-1, 1)
    t_values_final = torch.linspace(0, T, Nt).reshape(-1, 1)
    plot_grid = torch.cat((x_values, t_values), 1)
    # 创建网格
    #x_grid, t_grid = torch.meshgrid(x_values, t_values)
    #X_star = torch.hstack((x_grid.flatten()[:, None], t_grid.flatten()[:, None]))
    f_damp = G2(t_values_final)
    a = np.linspace(0, 1, Nx)

    #real_solu = (t_values_final + 1)**2
    real_solu = t_values_final + 1
    #real_solu = 2 * torch.sin(2 * pi * t_values_final) / (t_values_final + 1)

    ax[4].plot(a, f_damp.detach().cpu(), label="$\hat{u}$",
               alpha=alphas[0], linewidth=linewidth, color=colors[1],
               linestyle=linestyles[0])
    ax[4].plot(a, real_solu.detach(), label="$u$",
               alpha=alphas[0], linewidth=linewidth, color=colors[0],
               linestyle=linestyles[1])
    ax[4].set_xlabel('t')
    ax[4].set_ylabel('v')
    ax[4].set_title('Optimal control function')
    ax[4].legend(loc='upper right')

    diff_squared_error = torch.square(f_damp - real_solu)
    diff_squared = torch.square(real_solu)
    relative_l2_error = torch.sqrt(torch.sum(diff_squared_error))
    relative_l2 = torch.sqrt(torch.sum(diff_squared))
    relative = relative_l2_error / relative_l2
    print('Relative L2 error: ', relative)

    ax[5].plot(a, np.abs((real_solu - f_damp).detach().cpu().numpy()), label="$|\hat{u}-u|$",
               alpha=alphas[0], linewidth=linewidth, color=colors[0],
               linestyle=linestyles[1])
    ax[5].set_xlabel('x')
    ax[5].set_ylabel("$|\hat{u}-u|$")
    ax[5].set_title('Optimal control function error')
    ax[5].legend(loc='upper right')
    xmin = 0
    xmax = 1
    x_min_val = lambda t: 1 / (t + 1) + 1 / 3 * (t + 1) ** 2
    x_max_val = lambda t: 2 / (t + 1) + 1 / 3 * (t + 1) ** 2
    t_min_val = lambda x: x + 4 / 3
    real_solu_final = (x_values + 1) / 2 +4/3
    #x_min_val = lambda t: 1 / (t + 1) - torch.cos(2 * pi * t) / (t + 1) / pi
    #x_max_val = lambda t: 2 / (t + 1) - torch.cos(2 * pi * t) / (t + 1) / pi
    #t_min_val = lambda x: x + 1 - 1 / pi
    #real_solu_final = (x_values + 1) / 2 + 2
    #x_min_val = lambda t: 1 / (t + 1) + 1 / 4 * (t + 1) ** 3
    #x_max_val = lambda t: 2 / (t + 1) + 1 / 4 * (t + 1) ** 3
    #t_min_val = lambda x: x + 1 + 1 / 4

    Axy = (1 - x_values) * x_min_val(t_values) + x_values * x_max_val(t_values) + \
          (1 - t_values) * (t_min_val(x_values) - ((1 - x_values) * t_min_val(xmin * torch.ones_like(x_values))
                                                   + x_values * t_min_val(xmax * torch.ones_like(x_values))))

    if len(residuals.items()) == 3:
        f_final = G1(plot_grid)
        print('soft constrain')
    else:
        f_final =  Axy + x_values * (1 - x_values) * (1 - torch.exp(- t_values / T)) * G1(plot_grid)
        print('hard constrain')

    diff_squared_error_final = torch.square(f_final - real_solu_final)
    diff_squared_final = torch.square(real_solu_final)
    relative_l2_error_final = torch.sqrt(torch.sum(diff_squared_error_final))
    relative_l2_final = torch.sqrt(torch.sum(diff_squared_final))
    relative_final_final = relative_l2_error_final / relative_l2_final
    print('Final state Relative L2 error: ', relative_final_final)

    ax[6].plot(a, f_final.detach().cpu(), label="$\hat{u}$",
               alpha=alphas[0], linewidth=linewidth, color=colors[1],
               linestyle=linestyles[0])
    ax[6].plot(a, real_solu_final.cpu(), label="$u$",
               alpha=alphas[0], linewidth=linewidth, color=colors[0],
               linestyle=linestyles[1])
    ax[6].set_xlabel('x')
    ax[6].set_ylabel('u(x,5)')
    ax[6].set_title('Final state')
    ax[6].legend(loc='upper right')

    ax[7].plot(a, np.abs((real_solu_final - f_final).detach().cpu().numpy()), label="$|\hat{u}-u|$",
               alpha=alphas[0], linewidth=linewidth, color=colors[0],
               linestyle=linestyles[1])
    ax[7].set_xlabel('x')
    ax[7].set_ylabel("$|\hat{u}-u|$")
    ax[7].set_title('Final state')
    ax[7].legend(loc='upper right')

    if residuals:
        for i, (k, v) in enumerate(residuals.items()):
            if plot_sep_curves:
                ax[0][0].plot(np.arange(len(v)), v, label=k,
                              alpha=alphas[i], linewidth=linewidth, color=colors[i],
                              linestyle=linestyles[i])
                ax[0][0].set_yscale('log')
                ax[0][0].set_xlabel('Iteration')
                ax[0][0].set_ylabel('Residual/Bound/Initial')
                ax[0][0].legend(loc='upper right')

            else:
                ax[1].plot(np.arange(len(v)), v, label=k,
                           alpha=alphas[i], linewidth=linewidth, color=colors[i],
                           linestyle=linestyles[i])
                ax[1].set_yscale('log')
                ax[1].set_xlabel('Iteration')
                ax[1].set_ylabel('Residual/Bound/Initial')
                ax[1].legend(loc='upper right')


    if cost_objective:
        for i, (k, v) in enumerate(cost_objective.items()):
            if plot_sep_curves:
                ax[0][1].plot(np.arange(len(v)), v, label=k,
                              alpha=alphas[i], linewidth=linewidth, color=colors[i],
                              linestyle=linestyles[i])
                ax[0][1].set_yscale('log')
                ax[0][1].set_xlabel('Iteration')
                ax[0][1].set_ylabel('Cost_objective')
                ax[0][1].legend(loc='upper right')

            else:
                if isinstance(v, list):
                    v = torch.tensor(v)  # Convert list to tensor
                ax[2].plot(np.arange(len(v)), v.cpu(), label=k,
                           alpha=alphas[i], linewidth=linewidth, color=colors[i],
                           linestyle=linestyles[i])
                ax[2].set_yscale('log')
                ax[2].set_xlabel('Iteration')
                ax[2].set_ylabel('Cost_objective')
                ax[2].legend(loc='upper right')

    if save:
        print(f'Saving results to {dirname}')
        if not os.path.exists(dirname):
            os.mkdir(dirname)
        plt.savefig(os.path.join(dirname, f'lulu_augment_plot_{wj}.png'), bbox_inches='tight', dpi=300)
        for k, v in loss_dict.items():
            np.save(os.path.join(dirname, f"{k}_lulu_augment_loss"), v)

    else:
        plt.show()

def plot_multihead(mse_dict, loss_dict, resids_dict, save=False, dirname=None, alpha=0.8):

    plt.rc('axes', titlesize=20, labelsize=20)
    plt.rc('legend', fontsize=16)
    plt.rc('xtick', labelsize=18)
    plt.rc('ytick', labelsize=18)
    # plt.rcParams['text.usetex'] = True

    if save and not dirname:
        raise RuntimeError('Please provide a directory name `dirname` when `save=True`.')

    fig, ax = plt.subplots(1, 3, figsize=(12, 4))

    linestyles = ['solid', 'dashed', 'dashdot', 'dotted']*3
    linewidth = 2
    alphas = [alpha]*10
    colors = ['crimson', 'blue', 'skyblue', 'limegreen',
        'aquamarine', 'violet', 'black', 'brown', 'pink', 'gold']

    # MSEs (Pred vs Actual)
    for i, (k, v) in enumerate(mse_dict.items()):
        ax[0].plot(np.arange(len(v)), v, label=k,
            alpha=alphas[i], linewidth=linewidth, color=colors[i],
            linestyle=linestyles[i])

    if len(mse_dict.keys()) > 1:
        ax[0].legend(loc='upper right')
    ax[0].set_ylabel('Mean Squared Error')
    ax[0].set_xlabel('Iteration')
    ax[0].set_yscale('log')

    # GAN Losses
    for i, (k, v) in enumerate(loss_dict.items()):
        if k != 'LHS':
            ax[1].plot(np.arange(len(v)), v, label=k,
            alpha=alphas[i], linewidth=linewidth, color=colors[i],
            linestyle=linestyles[i])
    if len(loss_dict.keys()) > 1: 
        ax[1].legend(loc='upper right')
    ax[1].set_xlabel('Iteration')
    ax[1].set_ylabel('Loss')

    # L2 Residuals
    resid_vectors = resids_dict['resid']
    resid_l2s = [np.square(r_vec).mean() for r_vec in resid_vectors]
    ax[2].plot(np.arange(len(resid_l2s)), resid_l2s, alpha=alphas[0], 
        linewidth=linewidth, color=colors[0], linestyle=linestyles[0])
    ax[2].set_ylabel('Residuals ($L_2$ norm)')
    ax[2].set_xlabel('Iteration')
    ax[2].set_yscale('log')

    plt.tight_layout()

    if save:
        print(f'Saving results to {dirname}')
        if not os.path.exists(dirname):
            os.mkdir(dirname)
        plt.savefig(os.path.join(dirname, 'plot_multihead.png'), bbox_inches='tight', dpi=300)
        for k, v in mse_dict.items():
            np.save(os.path.join(dirname, f"{k}_mse"), v)
    else:
        plt.show()

def plot_3D(grid, pred_dict1, view=[35, -55], dims=None, save=False, dirname=None):
    """ 3D plotting function for PDEs """

    plt.rc('axes', titlesize=20, labelsize=20)
    # plt.rcParams['text.usetex'] = True

    #状态图像
    fig = plt.figure(figsize=(14,9))
    ax = fig.add_subplot(projection='3d')
    #grid = grid.numpy()
    x, y = grid[:, 0], grid[:, 1]
    xdim, ydim = dims.values()
    xx, yy = x.reshape((xdim, ydim)), y.reshape((xdim, ydim))
    for u in pred_dict1.values():
        u = u.cpu().numpy().reshape((xdim, ydim))
        break
    xlab, ylab = dims.keys()
    ax.set_xlabel(f'${xlab}$', labelpad=10, size=18)
    ax.set_ylabel(f'${ylab}$', labelpad=10, size=18)
    ax.set_zlabel('$u$', labelpad=12, size=18)
    ax.plot_surface(xx.cpu(), yy.cpu(), u, cmap=cm.coolwarm, rcount=500, ccount=500, alpha=0.8)
    ax.view_init(elev=view[0], azim=view[1])
    ax.tick_params(axis='z', which='major', pad=7)

    if save:
        plt.savefig(os.path.join(dirname, 'plot3D.png'), bbox_inches='tight', dpi=300)
    else:
        plt.show()

def plot_reps_results(arrs_dict,
    linewidth=2, alpha_line=0.8, alpha_shade=0.4, figsize=(12,8),
    pctiles = (2.5, 97.5), window=10, fname=None):

    plt.rc('axes', titlesize=24, labelsize=24)
    plt.rc('legend', fontsize=20)
    plt.rc('xtick', labelsize=24)
    plt.rc('ytick', labelsize=24)
    # plt.rcParams['text.usetex'] = True

    linestyles = ['solid', 'dashed', 'dashdot', 'dotted']
    colors = ['crimson', 'blue', 'skyblue', 'limegreen',
        'aquamarine', 'violet', 'black', 'brown', 'pink', 'gold']

    plt.figure(figsize=figsize)
    plt.yscale('log')

    arrs = list(arrs_dict.values())

    steps = np.arange(arrs[0].shape[1])

    for i, (k, a) in enumerate(arrs_dict.items()):
        a = pd.DataFrame(data=a).rolling(window, axis=1).mean().values
        plt.plot(steps, np.median(a, axis=0), label=k,
                 color=colors[i], linestyle=linestyles[i], linewidth=linewidth, alpha=alpha_line)
        lqt, upt = np.percentile(a, pctiles, axis=0)
        plt.fill_between(steps, lqt, upt, alpha=alpha_shade, color=colors[i])

    plt.legend(loc='lower left')
    # plt.legend(loc='upper right')
    # plt.xticks([0, 5000, 10000, 15000, 20000])
    plt.xlabel('Iteration')
    plt.ylabel('Mean squared error')

    if fname:
        plt.savefig(fname, dpi=300, bbox_inches='tight')
    else:
        plt.show()

def handle_overwrite(fname):#已经了解
    """ helper to handle case where we might overwrite """
    if os.path.exists(fname): #检查指定路径‘fname’是否存在
        owrite = check_overwrite(fname) # 如果存在调用函数检查是否覆盖
        if not owrite: #如果owrite是False则停止程序并退出
            print('Quitting to prevent overwriting.')
            exit(0)

def check_overwrite(fname):#已经了解
    """ helper function to get user input for overwriting """
    print(f'File found at {fname} and save=True.') #发现已存在文件，提示用户
    resp = input('Overwrite (y/n)? ').strip().lower() #提示输入y或n
    if resp == 'y': #如果输入y返回true 不进入handle_overwrite中的if not判断，程序不停止
        return True
    else:           ##如果输入n返回False 不进入handle_overwrite中的if not判断，程序不停止
        return False

class LambdaLR():
    """ Simple linear decay schedule """
    def __init__(self, n_epochs, offset, decay_start_epoch):
        assert ((n_epochs - decay_start_epoch) > 0), "Decay must start before the training session ends!"
        n_epochs = n_epochs
        offset = offset
        decay_start_epoch = decay_start_epoch

    def step(self, epoch):
        # max(0,_) ensures never < 0
        # min(0.9999,_) ensures never > 0.9999
        # ==> 1e-4 < 1 - min(1,max(0,_)) < 1
        return 1.0 - min(0.9999, max(0., epoch + offset - decay_start_epoch)/(n_epochs - decay_start_epoch))

def calc_gradient_penalty(disc, real_data, generated_data, gp_lambda, cuda=False):
    """ helper method for gradient penalty (WGAN-GP) """
    batch_size = real_data.size()[0]

    # Calculate interpolation
    alpha = torch.rand(batch_size, 1)
    alpha = alpha.expand_as(real_data)
    if cuda:
      alpha = alpha.cuda()
    interpolated = alpha * real_data.data + (1 - alpha) * generated_data.data
    interpolated = autograd.Variable(interpolated, requires_grad=True)
    if cuda:
      interpolated = interpolated.cuda()

    # Calculate probability of interpolated examples
    prob_interpolated = disc(interpolated)

    # Calculate gradients of probabilities with respect to examples
    gradients = autograd.grad(outputs=prob_interpolated, inputs=interpolated,
                          grad_outputs=torch.ones(prob_interpolated.size()).cuda() if cuda else torch.ones(
                                prob_interpolated.size()),
                          create_graph=True, retain_graph=True)[0]

    # Gradients have shape (batch_size, num_channels, img_width, img_height),
    # so flatten to easily take norm per example in batch
    gradients = gradients.view(batch_size, -1)
    # losses['gradient_norm'].append(gradients.norm(2, dim=1).mean().data[0])

    # Derivatives of the gradient close to 0 can cause problems because of
    # the square root, so manually calculate norm and add epsilon
    gradients_norm = torch.sqrt(torch.sum(gradients ** 2, dim=1) + 1e-12)

    # Return gradient penalty
    return gp_lambda * ((gradients_norm - 1) ** 2).mean()

def dict_product(dicts):
    """
    >>> list(dict_product(dict(number=[1,2], character='ab')))
    [{'character': 'a', 'number': 1},
     {'character': 'a', 'number': 2},
     {'character': 'b', 'number': 1},
     {'character': 'b', 'number': 2}]
    """
    return (dict(zip(dicts, x)) for x in itertools.product(*dicts.values()))

def exponential_weight_average(prev_weights, curr_weights, beta=0.999):
    """ returns exponential moving average of prev_weights and curr_weights
        (beta=0 => no averaging) """
    return beta*prev_weights + (1-beta)*curr_weights

def draw_neural_net(ax, left, right, bottom, top, layer_sizes):
    '''
    Draw a neural network cartoon using matplotilb.

    :usage:
        >>> fig = plt.figure(figsize=(12, 12))
        >>> draw_neural_net(fig.gca(), .1, .9, .1, .9, [4, 7, 2])

    :parameters:
        - ax : matplotlib.axes.AxesSubplot
            The axes on which to plot the cartoon (get e.g. by plt.gca())
        - left : float
            The center of the leftmost node(s) will be placed here
        - right : float
            The center of the rightmost node(s) will be placed here
        - bottom : float
            The center of the bottommost node(s) will be placed here
        - top : float
            The center of the topmost node(s) will be placed here
        - layer_sizes : list of int
            List of layer sizes, including input and output dimensionality

    :example2:
        # from pde_nn.utils import draw_neural_net
        # fig = plt.figure(figsize=(12, 12))
        # ax = fig.gca()
        # ax.axis('off')
        # draw_neural_net(ax, .1, .9, .1, .9, [1, 20, 20, 1])
        # fig.savefig('nn.png')
    '''
    n_layers = len(layer_sizes)
    v_spacing = (top - bottom)/float(max(layer_sizes))
    h_spacing = (right - left)/float(len(layer_sizes) - 1)
    # Nodes
    for n, layer_size in enumerate(layer_sizes):
        layer_top = v_spacing*(layer_size - 1)/2. + (top + bottom)/2.
        for m in range(layer_size):
            circle = plt.Circle((n*h_spacing + left, layer_top - m*v_spacing), v_spacing/4.,
                                color='w', ec='k', zorder=4)
            ax.add_artist(circle)
    # Edges
    for n, (layer_size_a, layer_size_b) in enumerate(zip(layer_sizes[:-1], layer_sizes[1:])):
        layer_top_a = v_spacing*(layer_size_a - 1)/2. + (top + bottom)/2.
        layer_top_b = v_spacing*(layer_size_b - 1)/2. + (top + bottom)/2.
        for m in range(layer_size_a):
            for o in range(layer_size_b):
                line = plt.Line2D([n*h_spacing + left, (n + 1)*h_spacing + left],
                                  [layer_top_a - m*v_spacing, layer_top_b - o*v_spacing], c='k')
                ax.add_artist(line)

def shake_weights(m, std=1):
    '''
    Adds normal noise to the weights of a model m
    '''
    with torch.no_grad():
        for p in m.parameters():
            p.add_(torch.randn(p.size()) * std)

def plot_grads(params, ax, logscale=False):
    '''
    Plots the gradients in the layers of a network given
    its named parameters and a matplotlib axis object.
    '''
    ave_grads = []
    max_grads = []
    layers = []
    for n, p in params:
        if(p.requires_grad) and ("bias" not in n):
            layers.append(n)
            ave_grads.append(p.grad.abs().mean())
            max_grads.append(p.grad.abs().max())
    ax[0].plot(ave_grads, alpha=0.3, color="b")
    ax[0].hlines(0, 0, len(ave_grads)+1, linewidth=1, color="k" )
    ax[0].set_xticks(range(0,len(ave_grads), 1))
    ax[0].set_xticklabels(layers, rotation="vertical")
    ax[0].set_xlim(xmin=0, xmax=len(ave_grads))
    if logscale:
        ax[0].set_yscale("log")
    ax[0].set_xlabel("Layers")
    ax[0].set_ylabel("Gradient")
    ax[0].grid(True)
    ax[1].bar(np.arange(0.5, len(max_grads)+0.5), max_grads, alpha=0.1, lw=1, color="c")
    ax[1].bar(np.arange(0.5, len(max_grads)+0.5), ave_grads, alpha=0.1, lw=1, color="b")
    ax[1].hlines(0, 0, len(ave_grads)+1, lw=2, color="k")
    ax[1].set_xticks(np.arange(0.5, len(ave_grads)+0.5))
    ax[1].set_xticklabels(layers, rotation="vertical")
    ax[1].set_xlim(left=0, right=len(ave_grads))
    ax[1].set_ylim(bottom = -0.001, top=0.02)
    ax[1].set_xlabel("Layers")
    ax[1].grid(True)
    ax[1].legend([Line2D([0], [0], color="c", lw=4),
                Line2D([0], [0], color="b", lw=4),
                Line2D([0], [0], color="k", lw=4)], ['max-gradient', 'mean-gradient', 'zero-gradient'], loc='upper center')   